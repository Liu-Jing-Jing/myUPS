//
//  JXCategoryTitleVerticalZoomCell.h
//  JXCategoryView
//
//  Created by jiaxin on 2019/2/14.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "JXCategoryTitleCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface JXCategoryTitleVerticalZoomCell : JXCategoryTitleCell

@end

NS_ASSUME_NONNULL_END
