//
//  NSDate+Helper.h
//  openweather-ios
//
//  Created by Harry Singh on 22/08/17.
//  Copyright © 2017 Harry Singh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Helper)

- (NSString *)convertToMessageFormat;
+ (NSDate *)convertSJTYServerFormatToNSDateWithStr:(NSString *)str;
- (NSString *)convertToSJTYServerFormat;
- (NSString *)convertToNumberStringYYYYmmDD;
-(NSString *)HH12Hour;
-(NSString *)dayName;

@end
