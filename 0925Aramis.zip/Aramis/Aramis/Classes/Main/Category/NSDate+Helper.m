//
//  NSDate+Helper.m
//  openweather-ios
//
//  Created by Harry Singh on 22/08/17.
//  Copyright © 2017 Harry Singh. All rights reserved.
//

#import "NSDate+Helper.h"

@implementation NSDate (Helper)
-  (NSString *)convertToMessageFormat
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"hh:mm dd/MM/yyyy"];
    return [formatter stringFromDate:self];
}
+ (NSString *)convertToSJTYServerFormat
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    return [formatter stringFromDate:self];
}

+ (NSDate *)convertSJTYServerFormatToNSDateWithStr:(NSString *)str
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    //NSString *sss = [formatter dateFromString:str];
    return [formatter dateFromString:str];
}
- (NSString *)convertToNumberStringYYYYmmDD
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"YYYY/MM/dd"];
    NSArray *unit = [[formatter stringFromDate:self] componentsSeparatedByString:@"/"];
    
    return [unit componentsJoinedByString:@""];
}
-(NSString *)HH12Hour{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setTimeStyle:NSDateFormatterShortStyle];
    [dateFormat setDateFormat:@"ha"];
    return [dateFormat stringFromDate:self];
}

-(NSString *)dayName{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"EEEE"];
    return [dateFormatter stringFromDate:self];
}

@end
