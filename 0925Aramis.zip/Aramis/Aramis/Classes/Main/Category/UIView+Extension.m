//
//  UIView+Extension.m
//  01-黑酷
//
//  Created by apple on 14-6-27.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "UIView+Extension.h"
#import <objc/runtime.h>
@implementation UIView (Extension)

- (UIViewController *)recursionView2ViewController
{
    UIView *view = self;
    __block UIViewController *viewController;
    __block void (^blocks)(UIView *) = nil;
    blocks = ^(UIView *view)
    {
        if([view.superview isKindOfClass:NSClassFromString(@"UIViewControllerWrapperView")])
        {
            Ivar ivar = class_getInstanceVariable([UIView class], "_viewDelegate");
            viewController = object_getIvar(view, ivar);
        }
        else blocks(view.superview);
    };
    blocks(view);
    return viewController;
}
- (void)setX:(CGFloat)x
{
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

- (CGFloat)x
{
    return self.frame.origin.x;
}

- (void)setY:(CGFloat)y
{
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

- (CGFloat)y
{
    return self.frame.origin.y;
}

- (void)setCenterX:(CGFloat)centerX
{
    CGPoint center = self.center;
    center.x = centerX;
    self.center = center;
}

- (CGFloat)centerX
{
    return self.center.x;
}

- (void)setCenterY:(CGFloat)centerY
{
    CGPoint center = self.center;
    center.y = centerY;
    self.center = center;
}

- (CGFloat)centerY
{
    return self.center.y;
}

- (void)setWidth:(CGFloat)width
{
    CGRect frame = self.frame;
    frame.size.width = width;
    self.frame = frame;
}

- (CGFloat)width
{
    return self.frame.size.width;
}

- (void)setHeight:(CGFloat)height
{
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
}

- (CGFloat)height
{
    return self.frame.size.height;
}

- (void)setSize:(CGSize)size
{
//    self.width = size.width;
//    self.height = size.height;
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
}

- (CGSize)size
{
    return self.frame.size;
}
//func zoomLoopAnimation() {
//    let animation = CABasicAnimation(keyPath: "transform.scale")
//    animation.duration = 0.8   // 设置动画时间
//    animation.repeatCount = 100000
//    animation.autoreverses = true
//    animation.fromValue = 1
//    animation.toValue = 1.1
//    animation.isRemovedOnCompletion = false  // 这个属性是为了离开页面后动画仍然存在
//    self.layer.add(animation, forKey: "scale-layer")
//}


- (void)zoomLoopAnimation
{
    CABasicAnimation *animation = [[CABasicAnimation alloc] init];
    animation.keyPath = @"transform.scale";
    animation.duration = 0.1;   // 设置动画时间
    animation.repeatCount = 1;
    animation.autoreverses = YES;
    animation.fromValue = @1;
    animation.toValue = @1.4;
    [animation setRemovedOnCompletion:NO]; // = NO;  // 这个属性是为了离开页面后动画仍然存在
//    self.layer.add(animation, forKey: "scale-layer");
    [self.layer addAnimation:animation forKey:@"scale-layer"];
}
@end
