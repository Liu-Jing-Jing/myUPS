//
//  MainTabBarViewController.m
//  iStep
//
//  Created by Mark on 2019/6/15.
//  Copyright © 2019年 Mark. All rights reserved.
//

#import "MainTabBarViewController.h"
#import "MKLTabBar.h"
#import "HomeViewController.h"
#import "HistoryChartViewController.h"
#import "MarketViewController.h"
#import "CompetitionViewController.h"
#import "MineViewController.h"
#import "MainNavigationViewController.h"
@interface MainTabBarViewController ()<MKLTabBarDelegate>
/**
 *  自定义的tabbar
 */
@property (nonatomic, weak) MKLTabBar *customTabBar;
@end

@implementation MainTabBarViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // 创建自定义tabbar
    [self addCustomTabBar];
    // 添加所有的子控制器
    [self addAllChildVcs];
}

/**
 *  初始化tabbar
 */
- (void)addCustomTabBar
{
    MKLTabBar *customTabBar = [[MKLTabBar alloc] init];
    customTabBar.frame = self.tabBar.bounds;
    customTabBar.tabbarDelegate = self;
    [self.tabBar addSubview:customTabBar];
    self.customTabBar = customTabBar;
}

#pragma mark - tabbar的代理方法
/**
 *  监听tabbar按钮的改变
 *  @param from   原来选中的位置
 *  @param to     最新选中的位置
 */
- (void)tabBar:(MKLTabBar *)tabBar didSelectedButtonFrom:(int)from to:(int)to
{
    self.selectedIndex = to;
}

/**
 *  添加所有的子控制器
 */
- (void)addAllChildVcs
{
    HomeViewController *home = [[HomeViewController alloc] init];
    [self addOneChlildVc:home title:@"首页" imageName:@"tab1" selectedImageName:@"tab1_selected"];
    HistoryChartViewController *message = [[HistoryChartViewController alloc] init];
    [self addOneChlildVc:message title:@"记录" imageName:@"tab2" selectedImageName:@"tab2_selected"];
    MarketViewController *discover = [[MarketViewController alloc] init];
    [self addOneChlildVc:discover title:@"香薰精油" imageName:@"tab3" selectedImageName:@"tab3_selected"];
    CompetitionViewController *competition = [[CompetitionViewController alloc] init];
    [self addOneChlildVc:competition title:@"设备" imageName:@"tab4" selectedImageName:@"tab4_selected"];
    MineViewController *mine = [[MineViewController alloc] init];
    [self addOneChlildVc:mine title:@"我的" imageName:@"tab5" selectedImageName:@"tab5_selected"];

}

/**
 *  添加一个子控制器
 *
 *  @param childVc           子控制器对象
 *  @param title             标题
 *  @param imageName         图标
 *  @param selectedImageName 选中的图标
 */
- (void)addOneChlildVc:(UIViewController *)childVc title:(NSString *)title imageName:(NSString *)imageName selectedImageName:(NSString *)selectedImageName
{
    // 1.设置控制器的属性
    childVc.tabBarItem.title = title;
    // 设置图标
    childVc.tabBarItem.image = [UIImage imageWithName:imageName];
    // 设置选中的图标
    UIImage *selectedImage = [UIImage imageWithName:selectedImageName];
    childVc.tabBarItem.selectedImage = [selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]; // 不要渲染成系统的颜色
    
    // 2.包装一个导航控制器
    MainNavigationViewController *nav = [[MainNavigationViewController alloc] initWithRootViewController:childVc];
    [self addChildViewController:nav];
    
    // 3.添加tabbar内部的按钮
    [self.customTabBar addTabBarButtonWithItem:childVc.tabBarItem];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    
    // [MMAudioTool playMusic:@"welcome.m4a"];
    // 删除系统自动生成的UITabBarButton
    for (UIView *child in self.tabBar.subviews)
    {
        if ([child isKindOfClass:NSClassFromString(@"UITabBarButton")])
        {
            child.hidden = YES;
            child.frame = CGRectMake(-100, -100, 0, 0);
            [child removeFromSuperview];
        }
        
        if ([child isKindOfClass:[UIControl class]])
        {
            child.hidden = YES;
            [child removeFromSuperview];
        }
    }
    self.tabBar.backgroundImage = [UIImage imageWithColor: UIColor.clearColor];
    self.tabBar.backgroundColor = [UIColor clearColor];
    [self.tabBar setShadowImage:UIImage.new];
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    for (UIView *child in self.tabBar.subviews)
    {
        if ([child isKindOfClass:NSClassFromString(@"UITabBarButton")])
        {
            child.hidden = YES;
            // child.frame = CGRectMake(-100, -100, 0, 0);
            [child removeFromSuperview];
        }
    }
    self.tabBar.backgroundImage = [UIImage imageWithColor: UIColor.clearColor];
    self.tabBar.backgroundColor = [UIColor clearColor];
    [self.tabBar setShadowImage:UIImage.new];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}
@end
