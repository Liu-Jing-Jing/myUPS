//
//  HistoryChartViewController.h
//  Natures
//
//  Created by 柏霖尹 on 2019/7/19.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContentBaseViewController.h"
#import "UpsModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface HistoryChartViewController : ContentBaseViewController <JXCategoryListContentViewDelegate>
//@property (nonatomic, assign) HistoryType type;
@property (nonatomic, strong) NSArray<UpsModel *>*modelArray;
@end

NS_ASSUME_NONNULL_END
