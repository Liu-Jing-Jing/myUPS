//
//  HistoryChartViewController.m
//  Natures
//
//  Created by 柏霖尹 on 2019/7/19.
//  Copyright © 2019 com.sjty. All rights reserved.
#import "HistoryChartViewController.h"
#import "JXCategoryTitleView.h"
#import "ChartViewController.h"
#import "EMSTwoButtonPopView.h"
#import "JXCategoryTitleView.h"
@interface HistoryChartViewController ()
@property (nonatomic, strong) JXCategoryTitleView *myCategoryView;
@property (nonatomic, strong) NSMutableArray *currentArray;


@end

@implementation HistoryChartViewController
- (void)viewDidLoad
{
    NSLog(@"%d", self.type);
    if (self.titles == nil)
    {
        self.titles = @[@"自然音", @"MONTH", @"YEAR"];
//        self.titles = @[@"DAY", @"WEEK", @"MONTH", @"YEAR"];
    }
    
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:34/255.0 green:37/255.0 blue:46/255.0 alpha:1];
    self.myCategoryView.titles = self.titles;
    [self setupData];
    self.navigationItem.rightBarButtonItem =  [[UIBarButtonItem alloc] initWithTitle:@"修改日期" style:UIBarButtonItemStyleDone target:self action:@selector(changeCalendar)];
    
    
    //传给下一个控制器
}

- (void)getHistoryData
{
    [UpsNetworkingTools getUpsRangeDataWithStartDate:nil endDate:nil success:^(id  _Nonnull response) {
        // 获得当天的历史数据
        NSLog(@"历史数据的模型---%@", response);
        self.modelArray = response;
        // 显示表格数据
    } failure:^(NSError * _Nonnull error) {
        //错误的处理
    }];
    
}

- (void)setupData
{
    //
//    NSMutableArray *currentDatas = [NSMutableArray array];
//
//    for (UpsModel *model in self.modelArray)
//    {
//        // 拿到每个模型中需要的属性值
//        id value = [model valueForKey:self.propertyName];
//        [currentDatas addObject:value];
//    }
//    self.currentArray = currentDatas;
}

#pragma mark - Delegate
- (id<JXCategoryListContentViewDelegate>)preferredListAtIndex:(NSInteger)index {
    
    ChartViewController *vc = [[ChartViewController alloc] init];
    vc.historyType = self.type;
#warning 设置控制器的内容
    if(index == 0)
    {
        vc.mode = DAY;
    }
    else if (index == 1)
    {
        vc.mode = MONTH;
    }
    else if (index == 1)
    {
        vc.mode = MONTH;
    }
    else if (index == 2)
    {
        vc.mode = YEAR;
    }
    
#warning 设置每种模式下的则线图
    //当天的模型
    vc.modelArray = self.modelArray;
    return vc;
}

- (JXCategoryTitleView *)myCategoryView {
    return (JXCategoryTitleView *)self.categoryView;
}

- (JXCategoryBaseView *)preferredCategoryView {
    return [[JXCategoryTitleView alloc] init];
}

#pragma mark - JXCategoryListContentViewDelegate

- (UIView *)listView {
    return self.view;
}
@end
