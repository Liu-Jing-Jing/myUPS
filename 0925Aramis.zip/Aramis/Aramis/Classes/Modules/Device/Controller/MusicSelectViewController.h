//
//  MusicSelectViewController.h
//  Aramis
//
//  Created by 柏霖尹 on 2019/9/9.
//  Copyright © 2019 Mark. All rights reserved.
//

#import "ContentBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface MusicSelectViewController : ContentBaseViewController<JXCategoryListContentViewDelegate>

@end

NS_ASSUME_NONNULL_END
