//
//  MusicSelectViewController.m
//  Aramis
//
//  Created by 柏霖尹 on 2019/9/9.
//  Copyright © 2019 Mark. All rights reserved.
//

#import "MusicSelectViewController.h"
#import "JXCategoryTitleView.h"
#import "MusicViewController.h"
#import "SleepAidOneViewController.h"
@interface MusicSelectViewController ()
@property (nonatomic, strong) JXCategoryTitleView *myCategoryView;

@end

@implementation MusicSelectViewController

- (void)viewDidLoad
{
    if (self.titles == nil)
    {
        self.titles = @[@"自然音", @"助眠曲", @"冥想曲"];
    }
    [super viewDidLoad];
    self.myCategoryView.titles = self.titles;
    //传给下一个控制器
}


#pragma mark - Delegate
- (id<JXCategoryListContentViewDelegate>)preferredListAtIndex:(NSInteger)index {
    
    MusicViewController *vc = [[MusicViewController alloc] init];
    //vc.historyType = self.type;
#warning 设置控制器的内容
    if(index == 0)
    {
        vc= [[SleepAidOneViewController alloc] init];
    }
    else if (index == 1)
    {
        vc = [[MusicViewController alloc] init];
    }
    else if (index == 2)
    {
        vc = [[MusicViewController alloc] init];
    }
//    else if (index == 2)
//    {
//        vc.mode = YEAR;
//    }
    
#warning 设置每种模式下的则线图
    //当天的模型
    return vc;
}

- (JXCategoryTitleView *)myCategoryView {
    return (JXCategoryTitleView *)self.categoryView;
}

- (JXCategoryBaseView *)preferredCategoryView {
    return [[JXCategoryTitleView alloc] init];
}

#pragma mark - JXCategoryListContentViewDelegate

- (UIView *)listView {
    NSLog(@"%@", NSStringFromCGRect(self.view.frame));
    return self.view;
}


-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
//    NSLog(@"%@", NSStringFromCGRect(self.view.frame));
}

//- (BOOL)listContainerView:(JXCategoryListContainerView *)listContainerView canInitListAtIndex:(NSInteger)index
//{
//    if(index) return YES;
//    
//    return NO;
//}
@end
