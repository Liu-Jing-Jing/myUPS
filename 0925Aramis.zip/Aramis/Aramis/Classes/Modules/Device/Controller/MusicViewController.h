//
//  MusicViewController.h
//  Aramis
//
//  Created by 柏霖尹 on 2019/9/11.
//  Copyright © 2019 Mark. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChartHeaderView.h"
NS_ASSUME_NONNULL_BEGIN

@interface MusicViewController : UITableViewController
@property (nonatomic, assign) CAL_MODE mode;
@end

NS_ASSUME_NONNULL_END
