//
//  MusicViewController.m
//  Aramis
//
//  Created by 柏霖尹 on 2019/9/11.
//  Copyright © 2019 Mark. All rights reserved.
//
#warning 显示歌曲界面

#import "MusicViewController.h"
#import "MusicListViewCell.h"
@interface MusicViewController ()

@end

@implementation MusicViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = UIColor.clearColor;
    self.tableView.backgroundColor = UIColor.clearColor;
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MusicListViewCell *cell = [MusicListViewCell cellforTableView:tableView];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70.0;
}

#pragma mark - JXCategoryListContentViewDelegate

- (UIView *)listView
{
    return self.view;
}

- (void)listDidAppear {}

- (void)listDidDisappear {}

@end
