//
//  HistoryChartViewController.h
//  Aramis
//
//  Created by 柏霖尹 on 2019/8/19.
//  Copyright © 2019 Mark. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef enum{
    DAY,
    WEEK,
    MONTH,
    YEAR
} CAL_MODE;

@interface HistoryChartViewController : UIViewController

@end
