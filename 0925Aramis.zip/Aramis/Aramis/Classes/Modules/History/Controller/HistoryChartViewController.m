//
//  HistoryChartViewController.m
//  Aramis
//  Created by 柏霖尹 on 2019/8/19.
//  Copyright © 2019 Mark. All rights reserved.
#import "HistoryChartViewController.h"

@interface HistoryChartViewController ()
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *buttons;
@property(nonatomic,strong)NSDate *currentDate;
- (IBAction)modeButtonClicked:(id)sender;
@end

@implementation HistoryChartViewController
- (instancetype)init
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"HistoryChartViewController" bundle:nil];
    [storyboard instantiateInitialViewController];
    //HistoryChartViewController *vc = [storyboard ins];
    return [storyboard instantiateInitialViewController];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self showinCurrentMonth:nil];
}

- (IBAction)modeButtonClicked:(UIButton *)sender
{
    for (UIButton *btn in self.buttons)
    {
        btn.selected = NO;
    }
    
    sender.selected = !sender.isSelected;
}


- (IBAction)previousMonthButton:(UIButton *)sender
{
    //得到当前的选择模式 拿到相应模式数据
    if (self.currentDate==nil)
    {
        self.currentDate=[NSDate date];
    }
    
    self.currentDate=[self getDateFromDate:self.currentDate withMonth:-1];
    [self getBeginAndEndWith:self.currentDate DateType:MONTH];
    NSDateFormatter *formatter=[[NSDateFormatter alloc] init];
    
    formatter.dateFormat=@"yyyy年MM月";
    
    self.navigationItem.title =[formatter stringFromDate:self.currentDate];
}

- (IBAction)showinCurrentMonth:(UIButton *)sender
{
    //
    self.currentDate = NSDate.date;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy年MM月"];
    self.navigationItem.title = [formatter stringFromDate:self.currentDate];
}
- (IBAction)nextMonthAction:(id)sender
{
    //得到当前的选择模式 拿到相应模式数据
    if (self.currentDate==nil)
    {
        self.currentDate=[NSDate date];
    }
    
    self.currentDate=[self getDateFromDate:self.currentDate withMonth:+1];
    [self getBeginAndEndWith:self.currentDate DateType:MONTH];
    NSDateFormatter *formatter=[[NSDateFormatter alloc] init];
    
    formatter.dateFormat=@"yyyy年MM月";
    
    self.navigationItem.title =[formatter stringFromDate:self.currentDate];
}
/**
 获取指定时间的几个月前日期或几个月后日期
 
 @param date 指定时间
 @param month 月的数量
 @return 返回日期
 */
-(NSDate *)getDateFromDate:(NSDate *)date withMonth:(NSInteger)month
{
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setMonth:month];
    NSCalendar *calender = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate *mDate = [calender dateByAddingComponents:comps toDate:date options:0];
    return mDate;
}
/**
 获取指定日期的月份开始时间、结束时间
 获取指定日期的星期开始时间、结束时间
 
 @param newDate 指定日期
 @param dateType 类型
 */
-(void)getBeginAndEndWith:(NSDate *)newDate DateType:(NSInteger)dateType
{
    if (newDate == nil) {
        newDate = [NSDate date];
    }
    
    double interval = 0;
    
    NSDate *beginDate = nil;
    
    NSDate *endDate = nil;
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    [calendar setFirstWeekday:2];//设定周一为周首日
    BOOL ok = false;
    if (dateType==WEEK) {
        ok = [calendar rangeOfUnit:NSCalendarUnitWeekOfMonth startDate:&beginDate interval:&interval forDate:newDate];
        
#warning
    }else if (dateType==MONTH )
    {
        ok = [calendar rangeOfUnit:NSCalendarUnitMonth startDate:&beginDate interval:&interval forDate:newDate];
    }
    //分别修改为 NSDayCalendarUnit NSWeekCalendarUnit NSYearCalendarUnit
    
    if (ok)
    {
        endDate = [beginDate dateByAddingTimeInterval:interval-1];
    }else {
        return;
    }
    
    
}
@end
