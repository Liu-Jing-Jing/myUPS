//
//  AlarmClockSettingViewController.h
//  Aramis
//
//  Created by Mark on 2019/9/8.
//  Copyright © 2019年 Mark. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewPagedFlowView.h"
@interface AlarmClockSettingViewController : UIViewController

@end
