//
//  AlarmClockSettingViewController.m
//  Aramis
//
//  Created by Mark on 2019/9/8.
//  Copyright © 2019年 Mark. All rights reserved.
//

#import "AlarmClockSettingViewController.h"
#define kModeCount 5
#define Width [UIScreen mainScreen].bounds.size.width
@interface AlarmClockSettingViewController ()<NewPagedFlowViewDelegate, NewPagedFlowViewDataSource>
/**  图片数组*/
@property (nonatomic, strong) NSMutableArray *imageArray;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePickerView;
@property (weak, nonatomic) IBOutlet UIView *coverFlowWrapper;
@property (weak, nonatomic) IBOutlet UILabel *natureWakeUpLabel;
@property (weak, nonatomic) IBOutlet UILabel *sleepModeLabel;
@property (strong, nonatomic) IBOutlet UITapGestureRecognizer *tapGest1;
@property (strong, nonatomic) IBOutlet UITapGestureRecognizer *tapGest2; // 贪睡模式的点击事件

@end

@implementation AlarmClockSettingViewController
- (instancetype)init
{
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"AlarmClockSettingViewController" bundle:nil];
    return [sb instantiateInitialViewController];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupUI];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)setupUI
{
    
    //
    [self.datePickerView performSelector:@selector(setHighlightsToday:) withObject:NO];
    [self.datePickerView setValue:[UIColor whiteColor] forKey:@"textColor"];
    
    for (int index = 0; index < kModeCount ; index++)
    {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"Yosemite%02d",index]];
        [self.imageArray addObject:image];
    }
    
    CGFloat coverWrapperH = self.coverFlowWrapper.height*0.70;
    NewPagedFlowView *pageFlowView = [[NewPagedFlowView alloc] initWithFrame:CGRectMake(0, 10, Width, coverWrapperH)];
    //pageFlowView.center = self.coverFlowWrapper.center;
    pageFlowView.delegate = self;
    pageFlowView.dataSource = self;
    pageFlowView.minimumPageAlpha = 0.1;
    pageFlowView.isCarousel = YES;
    pageFlowView.orientation = NewPagedFlowViewOrientationHorizontal;
    pageFlowView.isOpenAutoScroll = NO;
    [self.coverFlowWrapper addSubview:pageFlowView];
    [pageFlowView reloadData];
    //pageFlowView.transform =CGAffineTransformScale(pageFlowView.transform, 0.7, 0.7);
    self.coverFlowWrapper.backgroundColor = [UIColor clearColor];
    //添加到
    //self.datePickerView.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    for (UIView *view in self.datePickerView.subviews)
    {
        if ([view isKindOfClass:[UIView class]])
        {for (UIView *subView in view.subviews){
            if (subView.frame.size.height <= 1)
            {subView.backgroundColor = UIColor.whiteColor;}}}}
}


#pragma mark NewPagedFlowView Delegate
- (CGSize)sizeForPageInFlowView:(NewPagedFlowView *)flowView
{
    return CGSizeMake(Width - 120, (Width - 120) * 9 / 16);
}

- (void)didSelectCell:(UIView *)subView withSubViewIndex:(NSInteger)subIndex {
    
    NSLog(@"点击了第%ld张图",(long)subIndex + 1);
}

- (void)didScrollToPage:(NSInteger)pageNumber inFlowView:(NewPagedFlowView *)flowView {
    
    NSLog(@"ViewController 滚动到了第%ld页",pageNumber+1);
    NSString *msg = [NSString stringWithFormat:@"切换模式:%d", (int)pageNumber+1];
    //    [MBProgressHUD showMessage:msg];
    //    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //        [MBProgressHUD hideHUD];
    //    });
}

#pragma mark NewPagedFlowView Datasource
- (NSInteger)numberOfPagesInFlowView:(NewPagedFlowView *)flowView
{
    
    return self.imageArray.count;
    
}

- (PGIndexBannerSubiew *)flowView:(NewPagedFlowView *)flowView cellForPageAtIndex:(NSInteger)index{
    PGIndexBannerSubiew *bannerView = [flowView dequeueReusableCell];
    if (!bannerView) {
        bannerView = [[PGIndexBannerSubiew alloc] init];
        bannerView.tag = index;
        bannerView.layer.cornerRadius = 5;
        bannerView.layer.masksToBounds = YES;
    }
    //在这里下载网络图片
    //  [bannerView.mainImageView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:hostUrlsImg,imageDict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
    bannerView.mainImageView.image = self.imageArray[index];
    
    return bannerView;
}


#pragma mark --懒加载
- (NSMutableArray *)imageArray
{
    if (_imageArray == nil) {
        _imageArray = [NSMutableArray array];
    }
    return _imageArray;
}
- (IBAction)natureWakeUpAction:(id)sender
{
    //
    NSArray *timeArray = @[@"提前五分钟", @"提前十分钟", @"提前十五分钟", @"提前三十分钟"];
    // 切换自然醒模式下的时间
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"自然醒" message:@"" preferredStyle:UIAlertControllerStyleActionSheet];
    
    for (NSString *title in timeArray)
    {
        [alertVC addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            self.natureWakeUpLabel.text = title;
        }]];
    }
    [alertVC addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {}]];
    [self presentViewController:alertVC animated:YES completion:NULL];
}

- (IBAction)sleepModeAction:(id)sender
{
    NSArray *timeArray = @[@"提前五分钟", @"提前十分钟", @"提前十五分钟", @"提前三十分钟"];
    // 切换自然醒模式下的时间
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"自然醒" message:@"" preferredStyle:UIAlertControllerStyleActionSheet];
    
    for (NSString *title in timeArray)
    {
        [alertVC addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            self.natureWakeUpLabel.text = title;
        }]];
    }
    [alertVC addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {}]];
    [self presentViewController:alertVC animated:YES completion:NULL];
}

@end
