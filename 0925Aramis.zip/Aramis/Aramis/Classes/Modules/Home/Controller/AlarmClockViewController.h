//
//  AlarmClockViewController.h
//  Aramis
//
//  Created by 柏霖尹 on 2019/8/20.
//  Copyright © 2019 Mark. All rights reserved.




#import <UIKit/UIKit.h>
@class HomeAlarmModel;
@interface AlarmClockViewController : UIViewController
typedef void(^PopActionBlock)(HomeAlarmModel * model);
/** 贪睡模式的时间*/
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *natureTimeLabel;
@property (nonatomic, copy) PopActionBlock pop;

@end
