//
//  AlarmClockViewController.m
//  Aramis
//
//  Created by 柏霖尹 on 2019/8/20.
//  Copyright © 2019 Mark. All rights reserved.
//  设置闹钟的VC

#import "AlarmClockViewController.h"
#import "NewPagedFlowView.h"
#import "PGIndexBannerSubiew.h"
#import "NSString+BlockExtension.h"
#import "HomeAlarmModel.h"
#import "MBProgressHUD+MJ.h"
#define kModeCount 5
#define Width [UIScreen mainScreen].bounds.size.width
@interface AlarmClockViewController ()<NewPagedFlowViewDelegate, NewPagedFlowViewDataSource>
@property (strong, nonatomic) IBOutletCollection(UISwitch) NSArray *allSwitch;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *weekButtons;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *dateButtons;
@property (weak, nonatomic) IBOutlet UIView *coverFlowWrapper;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePickerView;
@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;
/**
 *  图片数组
 */
@property (weak, nonatomic) IBOutlet UISwitch *mySwitch;
@property (nonatomic, strong) NSMutableArray *imageArray;
@end

@implementation AlarmClockViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIImageView *backgroundImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"home_background2"]];
    backgroundImage.contentMode = UIViewContentModeScaleToFill;
    //[self.tableView.backgroundView sendSubviewToBack:backgroundImage];
    //self.tableView.backgroundView = backgroundImage;
    self.mySwitch.transform = CGAffineTransformScale(self.mySwitch.transform, 0.7, 0.7);
    // Setup UI
    //self.title = @"唤醒设置";
    
    for (UISwitch *switchView in self.allSwitch)
    {
        switchView.transform = CGAffineTransformScale(switchView.transform, 0.7, 0.7);
    }
    for (int index = 0; index < kModeCount ; index++)
    {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"Yosemite%02d",index]];
        [self.imageArray addObject:image];
    }
    [self setupUI];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:UIBarButtonItemStyleDone target:self action:@selector(saveAction)];
    [self.datePickerView performSelector:@selector(setHighlightsToday:) withObject:NO];
    [self.datePickerView setValue:[UIColor whiteColor] forKey:@"textColor"];
    self.datePickerView.datePickerMode = UIDatePickerModeDate;
    self.datePickerView.datePickerMode = UIDatePickerModeTime;  //真正想要展示的mode

    for (UIButton *btn in self.weekButtons)
    {
        [btn addTarget:self action:@selector(selectAction:) forControlEvents:UIControlEventTouchDown];
    }
    // week title
#warning weekname
    NSArray *weekArray = @[@"周一", @"周二", @"周三", @"周四", @"周五", @"周六", @"周日"];
    for(int i=0;i<self.weekButtons.count;i++)
    {
        [(UIButton *)self.dateButtons[i] setTitle:weekArray[i] forState:UIControlStateNormal];
    }
    [(UIButton *)self.dateButtons[0] setTitle:@"周一" forState:UIControlStateNormal];
    [(UIButton *)self.dateButtons[1] setTitle:@"周二" forState:UIControlStateNormal];
    [(UIButton *)self.dateButtons[2] setTitle:@"周三" forState:UIControlStateNormal];
    [(UIButton *)self.dateButtons[3] setTitle:@"周四" forState:UIControlStateNormal];
    [(UIButton *)self.dateButtons[4] setTitle:@"周五" forState:UIControlStateNormal];
    [(UIButton *)self.dateButtons[5] setTitle:@"周六" forState:UIControlStateNormal];
    [(UIButton *)self.dateButtons[6] setTitle:@"周日" forState:UIControlStateNormal];
    
    
}

// 选择星期的按钮
- (IBAction)selectAction:(UIButton *)sender
{
    // 遍历所有的按钮 拿到每个
    sender.selected = !sender.isSelected;
}

- (void)saveAction
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"HH/mm";
    NSLog(@"正在保存 %@", [formatter stringFromDate: self.datePickerView.date]);
    
    HomeAlarmModel *model = [[HomeAlarmModel alloc] init];
    model.alarmDate = self.datePickerView.date;
    if(self.pop)
    {
        self.pop(model);
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.navigationController popViewControllerAnimated:YES];
    });
}



- (void)setupUI
{
    NewPagedFlowView *pageFlowView = [[NewPagedFlowView alloc] initWithFrame:CGRectMake(-80, -32, Width+160, Width * 9 / 16)];
    pageFlowView.delegate = self;
    pageFlowView.dataSource = self;
    pageFlowView.minimumPageAlpha = 0.1;
    pageFlowView.isCarousel = YES;
    pageFlowView.orientation = NewPagedFlowViewOrientationHorizontal;
    pageFlowView.isOpenAutoScroll = NO;
    
    //初始化pageControl
    UIPageControl *pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, pageFlowView.frame.size.height - 32, Width, 8)];
    pageFlowView.pageControl = pageControl;
    //[pageFlowView addSubview:pageControl];
    [pageFlowView reloadData];
    pageFlowView.transform =CGAffineTransformScale(pageFlowView.transform, 0.7, 0.7);
    [self.coverFlowWrapper addSubview:pageFlowView];
    
    //添加到
    //self.datePickerView.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    for (UIView *view in self.datePickerView.subviews)
    {
        if ([view isKindOfClass:[UIView class]])
        {for (UIView *subView in view.subviews){
            if (subView.frame.size.height < 1)
            {subView.backgroundColor = UIColor.whiteColor;}}}}
}


#pragma mark NewPagedFlowView Delegate
- (CGSize)sizeForPageInFlowView:(NewPagedFlowView *)flowView
{
    return CGSizeMake(Width - 60, (Width - 60) * 9 / 16);
}

- (void)didSelectCell:(UIView *)subView withSubViewIndex:(NSInteger)subIndex {
    
    NSLog(@"点击了第%ld张图",(long)subIndex + 1);
}

- (void)didScrollToPage:(NSInteger)pageNumber inFlowView:(NewPagedFlowView *)flowView {
    
    NSLog(@"ViewController 滚动到了第%ld页",pageNumber+1);
    NSString *msg = [NSString stringWithFormat:@"切换模式:%d", (int)pageNumber+1];
//    [MBProgressHUD showMessage:msg];
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [MBProgressHUD hideHUD];
//    });
}

#pragma mark NewPagedFlowView Datasource
- (NSInteger)numberOfPagesInFlowView:(NewPagedFlowView *)flowView
{
    
    return self.imageArray.count;
    
}

- (PGIndexBannerSubiew *)flowView:(NewPagedFlowView *)flowView cellForPageAtIndex:(NSInteger)index{
    PGIndexBannerSubiew *bannerView = [flowView dequeueReusableCell];
    if (!bannerView) {
        bannerView = [[PGIndexBannerSubiew alloc] init];
        bannerView.tag = index;
        bannerView.layer.cornerRadius = 4;
        bannerView.layer.masksToBounds = YES;
    }
    //在这里下载网络图片
    //  [bannerView.mainImageView sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:hostUrlsImg,imageDict[@"img"]]] placeholderImage:[UIImage imageNamed:@""]];
    bannerView.mainImageView.image = self.imageArray[index];
    
    return bannerView;
}


#pragma mark --懒加载
- (NSMutableArray *)imageArray {
    if (_imageArray == nil) {
        _imageArray = [NSMutableArray array];
    }
    return _imageArray;
}
#pragma mark -- TableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 3)
    {
        //
        NSLog(@"切换歌曲");
    }
    else if(indexPath.row == 5)
    {
        //分钟
        NSArray *timeArray = @[@"提前五分钟", @"提前十分钟", @"提前十五分钟", @"提前三十分钟"];
        // 切换自然醒模式下的时间
        UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"" message:@"自然醒" preferredStyle:UIAlertControllerStyleActionSheet];
        
        for (NSString *title in timeArray)
        {
            [alertVC addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                self.natureTimeLabel.text = title;
            }]];
        }
        [alertVC addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {}]];
        [self presentViewController:alertVC animated:YES completion:NULL];
    }
    else if(indexPath.row == 7)
    {
        // 切换贪睡模式下的时间
#warning 修改准确的时间选择
        NSArray *timeArray = @[@"提前五分钟", @"提前十分钟", @"提前十五分钟", @"提前三十分钟"];
        // 切换自然醒模式下的时间
        UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"" message:@"贪睡" preferredStyle:UIAlertControllerStyleActionSheet];
        
        for (NSString *title in timeArray)
        {
            [alertVC addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                self.timeLabel.text = title;
            }]];
        }
        [alertVC addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {}]];
        [self presentViewController:alertVC animated:YES completion:NULL];
    }
}


- (instancetype)init
{
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"".loadStoryboard(@"AlarmClockViewController") bundle:nil];
    return [sb instantiateInitialViewController];
}
@end
