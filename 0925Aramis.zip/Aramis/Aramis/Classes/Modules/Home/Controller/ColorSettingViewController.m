//
//  ColorSettingViewController.m
//  Aramis
//
//  Created by 柏霖尹 on 2019/8/21.
//  Copyright © 2019 Mark. All rights reserved.
//

#import "ColorSettingViewController.h"
#import "PaletteView.h"
//#import "ColorBar.h"
@interface ColorSettingViewController ()
@property (weak, nonatomic) IBOutlet PaletteView *platteView;

@end

@implementation ColorSettingViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupUI];
}

- (void)setupUI
{
        self.platteView.colorPickerImage=[UIImage imageNamed:@"piccolor.png"];
}

- (instancetype)init
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"ColorSettingViewController" bundle:nil];
    [storyboard instantiateInitialViewController];
    //HistoryChartViewController *vc = [storyboard ins];
    return [storyboard instantiateInitialViewController];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
