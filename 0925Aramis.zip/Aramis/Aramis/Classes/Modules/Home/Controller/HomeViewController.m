//
//  HomeViewController.m
//  iStep
//
//  Created by Mark on 2019/6/15.
//  Copyright © 2019年 Mark. All rights reserved.
//

#import "HomeViewController.h"
#import "UIBarButtonItem+Extension.h"
#import "Slider.h"
#import "AlarmClockViewController.h"
#import "RelaxSettingViewController.h"
#import "MKLTabBarButton.h"
#import "MKLTabBar.h"
#import "ColorSettingViewController.h"
#import "AlarmClockSettingViewController.h"
#import "HomeAlarmModel.h"
#import "MusicSelectViewController.h"

#define MJImageCount 3
@interface HomeViewController ()
@property (weak, nonatomic) IBOutlet UILabel *alarmTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *alarmHintLabel;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;
@property (weak, nonatomic) IBOutlet UIView *whiteCircleView;

@property (weak, nonatomic) IBOutlet UIImageView *innerCircleImageView;
@property (strong, nonatomic) NSTimer *timer;

@end

@implementation HomeViewController
// Lifecycle
- (void)viewDidLoad
{
    self.navigationItem.title = @"";
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setupBarItem];
}

- (void)chatButtonClick{}
- (void)setupBarItem
{
    //self.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithImage:@"scanL" highImage:@"scanL" target:self action:@selector(scanBbuttonClick)];
    //self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithImage:@"chatR" highImage:@"chatR" target:self action:@selector(chatButtonClick)];
}

- (IBAction)pushToAlarmClockVC
{
    
    [self.whiteCircleView zoomLoopAnimation];
//    AlarmClockViewController *alarmVC = [[UIStoryboard storyboardWithName:@"AlarmClockViewController" bundle:nil] instantiateInitialViewController];
//    alarmVC.pop = ^(HomeAlarmModel *model) {
//        // pop修改主页的时间
//
//        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
//        formatter.dateFormat = @"HH/mm";
//        NSLog(@"正在保存 %@", [formatter stringFromDate:model.alarmDate]);
//        NSString *dateString = [formatter stringFromDate:model.alarmDate];
//        int hh = [[dateString componentsSeparatedByString:@"/"] firstObject].intValue;
//
//        NSString *first = [[dateString componentsSeparatedByString:@"/"] firstObject];
//        NSString *minutes = [[dateString componentsSeparatedByString:@"/"] lastObject];
//
//        self.alarmTimeLabel.text = [NSString stringWithFormat:@"%@点%@分", first, minutes];
//
//        self.alarmHintLabel.text = @"闹钟已开";
//    };
//
#warning 111
    AlarmClockSettingViewController *asVC = [[AlarmClockSettingViewController alloc] init];
    [self.navigationController pushViewController:asVC animated:YES];
    
}


- (IBAction)pushToRelaxSetting:(id)sender
{
    // 睡眠  助眠设置
    UIViewController *sleepSettingVC = [[UIViewController alloc] init];
    sleepSettingVC.view.backgroundColor = [UIColor redColor];
        NSLog(@"%@", self.navigationController.class);
    [self.navigationController pushViewController:sleepSettingVC animated:YES];
    
}


/** 底部的三大按钮的布局 */
- (IBAction)openLightSettingVC:(id)sender
{
    [(UIButton *)sender zoomLoopAnimation];
    ColorSettingViewController *sleepSettingVC = [[ColorSettingViewController alloc] init];
    sleepSettingVC.title = @"灯光控制";
    [self.navigationController pushViewController:sleepSettingVC animated:YES];

}
- (IBAction)machineTurnonAction:(UIButton *)sender
{
    [sender zoomLoopAnimation];
}
- (IBAction)sleepAidAction:(id)sender {
}

// 助眠设置的开关
- (IBAction)openMusicSettingVC:(UIButton *)sender
{
    [sender zoomLoopAnimation];
    MusicSelectViewController *musicVC = [[MusicSelectViewController alloc] init];
    
    JXCategoryTitleView *titleCategoryView = (JXCategoryTitleView *)musicVC.categoryView;
    titleCategoryView.titleColorGradientEnabled = NO;
    titleCategoryView.titleLabelMaskEnabled = NO;
    JXCategoryIndicatorBackgroundView *backgroundView = [[JXCategoryIndicatorBackgroundView alloc] init];
    backgroundView.indicatorWidthIncrement = 10;
    backgroundView.indicatorHeight = 20;
    //titleCategoryView.indicators = @[backgroundView];
    titleCategoryView.titleColorGradientEnabled = YES;
    titleCategoryView.titleLabelZoomEnabled = YES;
    titleCategoryView.titleLabelZoomScale = 1.75;
    [self.navigationController pushViewController:musicVC animated:YES];
    
}



@end
