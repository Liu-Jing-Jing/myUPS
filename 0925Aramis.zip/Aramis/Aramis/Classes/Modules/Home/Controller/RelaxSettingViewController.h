//
//  RelaxSettingViewController.h
//  Aramis
//
//  Created by Mark on 2019/8/21.
//  Copyright © 2019年 Mark. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RelaxSettingViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UILabel *natureTimeLabel;

@end
