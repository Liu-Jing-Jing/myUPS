//
//  RelaxSettingViewController.m
//  Aramis
//
//  Created by Mark on 2019/8/21.
//  Copyright © 2019年 Mark. All rights reserved.
//

#import "RelaxSettingViewController.h"
#import "NewPagedFlowView.h"
#import "PGIndexBannerSubiew.h"
#import "NSString+BlockExtension.h"
#import "MBProgressHUD+MJ.h"
#define kModeCount 5
#define Width [UIScreen mainScreen].bounds.size.width
@interface RelaxSettingViewController ()<NewPagedFlowViewDelegate, NewPagedFlowViewDataSource>
@property (weak, nonatomic) IBOutlet UIView *coverFlowWrapper;
@property (nonatomic, strong) NSMutableArray *imageArray;
@end

@implementation RelaxSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // setup UI
    UIImageView *backgroundImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"alarm_setting_background"]];
    backgroundImage.contentMode = UIViewContentModeScaleToFill;
    backgroundImage.frame = self.tableView.bounds;
    self.tableView.backgroundView = backgroundImage;
    
    [self setupUI];
}


- (void)setupUI
{
    
    for (int index = 0; index < kModeCount ; index++)
    {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"Yosemite%02d",index]];
        [self.imageArray addObject:image];
    }
    //
    NewPagedFlowView *pageFlowView = [[NewPagedFlowView alloc] initWithFrame:CGRectMake(-80, 2, Width+160, Width * 9 / 16)];
    pageFlowView.delegate = self;
    pageFlowView.dataSource = self;
    pageFlowView.minimumPageAlpha = 0.1;
    pageFlowView.isCarousel = YES;
    pageFlowView.orientation = NewPagedFlowViewOrientationHorizontal;
    pageFlowView.isOpenAutoScroll = NO;
    
    //初始化pageControl
    UIPageControl *pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, pageFlowView.frame.size.height - 32, Width, 8)];
    pageFlowView.pageControl = pageControl;
    //[pageFlowView addSubview:pageControl];
    [pageFlowView reloadData];
    pageFlowView.transform =CGAffineTransformScale(pageFlowView.transform, 0.7, 0.7);
    [self.coverFlowWrapper addSubview:pageFlowView];
}


#pragma mark NewPagedFlowView Delegate
- (CGSize)sizeForPageInFlowView:(NewPagedFlowView *)flowView
{
    return CGSizeMake(Width - 60, (Width - 60) * 9 / 16);
}

- (void)didSelectCell:(UIView *)subView withSubViewIndex:(NSInteger)subIndex {
    
    NSLog(@"点击了第%ld张图",(long)subIndex + 1);
}

- (void)didScrollToPage:(NSInteger)pageNumber inFlowView:(NewPagedFlowView *)flowView {
    
    NSLog(@"ViewController 滚动到了第%ld页",pageNumber+1);
    
    //
    NSString *msg = [NSString stringWithFormat:@"切换模式:%d", (int)pageNumber+1];
}

#pragma mark NewPagedFlowView Datasource
- (NSInteger)numberOfPagesInFlowView:(NewPagedFlowView *)flowView {
    
    return self.imageArray.count;
    
}

- (PGIndexBannerSubiew *)flowView:(NewPagedFlowView *)flowView cellForPageAtIndex:(NSInteger)index{
    PGIndexBannerSubiew *bannerView = [flowView dequeueReusableCell];
    if (!bannerView) {
        bannerView = [[PGIndexBannerSubiew alloc] init];
        bannerView.tag = index;
        bannerView.layer.cornerRadius = 4;
        bannerView.layer.masksToBounds = YES;
    }
    bannerView.mainImageView.image = self.imageArray[index];
    
    return bannerView;
}

#pragma mark --懒加载
- (NSMutableArray *)imageArray {
    if (_imageArray == nil) {
        _imageArray = [NSMutableArray array];
    }
    return _imageArray;
}

//- (instancetype)init
//{
//    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"".loadStoryboard(@"RelaxSettingViewController") bundle:nil];
//    return [sb instantiateInitialViewController];
//}
#pragma mark - Table view data source
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 3)
    {
        //
        NSLog(@"切换歌曲");
    }
    else if(indexPath.row == 4)
    {
        //分钟
        NSArray *timeArray = @[@"提前五分钟", @"提前十分钟", @"提前十五分钟", @"提前三十分钟"];
        // 切换自然醒模式下的时间
        UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"" message:@"自然醒" preferredStyle:UIAlertControllerStyleActionSheet];
        
        for (NSString *title in timeArray)
        {
            [alertVC addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                self.natureTimeLabel.text = title;
            }]];
        }
        [alertVC addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {}]];
        [self presentViewController:alertVC animated:YES completion:NULL];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
