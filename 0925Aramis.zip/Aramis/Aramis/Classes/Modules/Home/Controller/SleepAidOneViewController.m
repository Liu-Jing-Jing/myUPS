//
//  SleepAidOneViewController.m
//  Aramis
//
//  Created by 柏霖尹 on 2019/9/10.
//  Copyright © 2019 Mark. All rights reserved.
//  助眠模式下的设置

#import "SleepAidOneViewController.h"
#import "MusicCellModel.h"
#import "MJProductCell.h"
#import "RedSlider.h"
#import "MJAudioTool.h"
#define kAidCellID @"cell"

@interface SleepAidOneViewController()<UICollectionViewDelegate, UICollectionViewDataSource>
@property (nonatomic, strong) NSString *currentName;
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *presetImageViews;
@property (weak, nonatomic) IBOutlet UIImageView *presetImage1;
@property (weak, nonatomic) IBOutlet UIImageView *presetImageSec;
@property (weak, nonatomic) IBOutlet UIImageView *presetImageThrid;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomToSafeAreaConstraint;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *volumeBtns;
@property (strong, nonatomic) IBOutletCollection(RedSlider) NSArray *redSliders;
@property (nonatomic, strong) NSMutableArray *selectItem; //保存图片的名字
@property (nonatomic, strong) NSArray *models; //存放所有的音效模型
@property (nonatomic, assign) int presetIndex;
@end

@implementation SleepAidOneViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setupUI];
    
    
    //
    for (UIImageView *view in self.presetImageViews)
    {
        view.hidden = YES;
    }
    
    for (UIImageView *view in self.volumeBtns)
    {
        view.hidden = YES;
    }
    
    for (UIImageView *view in self.redSliders)
    {
        view.hidden = YES;
    }
    
    [self.presetImageViews[0] setTag:-1];
        [self.presetImageViews[1] setTag:-1];
        [self.presetImageViews[2] setTag:-1];
}


- (void)setupUI
{
    self.bottomToSafeAreaConstraint.constant = self.navigationController.navigationBar.frame.size.height + [[UIApplication sharedApplication] statusBarFrame].size.height+20;
    // 1.流水布局
    UICollectionViewFlowLayout *layout = (UICollectionViewFlowLayout *)[self.collectionView collectionViewLayout];
    // 2.每个cell的尺寸
    layout.itemSize = CGSizeMake(80, 80);
    // 3.设置cell之间的水平间距
    layout.minimumInteritemSpacing = 0;
    // 4.设置cell之间的垂直间距
    layout.minimumLineSpacing = 10;
    // 5.设置四周的内边距
    layout.sectionInset = UIEdgeInsetsMake(layout.minimumLineSpacing, 0, 0, 0);
    self.collectionView.delegate = self;
    UINib *nib = [UINib nibWithNibName:@"MJProductCell" bundle:nil];
    [self.collectionView registerNib:nib forCellWithReuseIdentifier:kAidCellID];
    self.collectionView.backgroundColor = UIColor.clearColor;
}

- (void)updateSelectItemUI:(NSIndexPath *)itemPath
{
    
    if(self.selectItem.count==0)
    {}
    else if (self.selectItem.count==1)
    {
        self.presetImage1.tag = itemPath.item;
        self.presetImage1.image = [UIImage imageNamed:self.selectItem.firstObject];
    }
    else if (self.selectItem.count==2)
    {
        self.presetImage1.image = [UIImage imageNamed:self.selectItem.lastObject];
        self.presetImageSec.image = [UIImage imageNamed:self.selectItem.firstObject];
    }
    else if (self.selectItem.count>=3)
    {
        self.presetImage1.tag = itemPath.item;
        self.presetImageSec.tag = itemPath.item;
        self.presetImage1.image = [UIImage imageNamed:self.selectItem[2]];
        self.presetImageSec.image = [UIImage imageNamed:self.selectItem[1]];
        self.presetImageThrid.image = [UIImage imageNamed:self.selectItem[0]];
    }
}
#warning CollectionView Delegate 方法
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    MJProductCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kAidCellID forIndexPath:indexPath];
    
    MusicCellModel *data=self.models[indexPath.row];

    cell.cellModel=data;
    return cell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.models.count;
}

#pragma mark - 代理方法
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *filename = [NSString stringWithFormat:@"m_%02d.wav", indexPath.item];
    [MJAudioTool playMusic:filename];
    
    MusicCellModel *p = self.models[indexPath.item];
    p.selected = YES;
    MJProductCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    
    NSArray *names = [NSArray new];
    if(self.selectItem.count==0)
    {
        names = [NSArray new];
    }
    else if (self.selectItem.count==1)
    {
        names = @[self.selectItem.firstObject];
    }
    else if (self.selectItem.count==2)
    {
        names = [self.selectItem.copy subarrayWithRange:NSMakeRange(0, 2)];
    }
    else
    {names = [self.selectItem.copy subarrayWithRange:NSMakeRange(0, 3)];
        
    }
    if(![names containsObject:p.icon])
    {
        [self.selectItem insertObject:p.icon atIndex:0];
        [self updateSelectItemUI:indexPath];
    }
    cell.cellModel = p;
    
    
    //show UI
    if(self.presetIndex>2) return;
    [self.presetImageViews[_presetIndex] setHidden:NO];
    [self.volumeBtns[_presetIndex] setHidden:NO];
    [self.redSliders[_presetIndex] setHidden:NO];
    self.presetIndex++;
    
}

- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath
{
    MusicCellModel *p = self.models[indexPath.item];
    p.selected = NO;
    MJProductCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    cell.cellModel = p;
    //NSLog(@"之前点击了点击了---%@", p.title);
    self.currentName = p.icon;
}

- (BOOL)collectionView:(UICollectionView *)collectionView shouldDeselectItemAtIndexPath:(NSIndexPath *)indexPath
{
    //

    return YES;
}

- (NSArray *)models
{
    if (_models == nil)
    {
        
        // JSON文件的路径
        NSString *path = [[NSBundle mainBundle] pathForResource:@"musicIcon.json" ofType:nil];
        
        NSData *data = [NSData dataWithContentsOfFile:path];
        NSArray *dictArray = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];

        NSMutableArray *productArray = [NSMutableArray array];
        for (NSDictionary *dict in dictArray)
        {
            MusicCellModel *p = [MusicCellModel musicCellModelWithDict:dict];
            [productArray addObject:p];
        }
        
        _models = productArray;
    }
    return _models;
}


#pragma mark - JXCategoryListContentViewDelegate

- (UIView *)listView
{
    NSLog(@"%@", NSStringFromCGRect(self.view.frame));
    return self.view;
}

- (void)listDidAppear {}

- (void)listDidDisappear {}

- (void)viewDidLayoutSubviews
{
}


- (NSMutableArray *)selectItem
{
    if(_selectItem == nil)
    {
        _selectItem = [NSMutableArray array];
        
    }
    return _selectItem;
}



- (IBAction)addVolumeAction:(UIButton *)sender
{
    //[sender zoomLoopAnimation];
    RedSlider *slider =self.redSliders[sender.tag];
    slider.currentValue +=10;
    if(slider.currentValue >= slider.maximumValue) slider.currentValue = slider.maximumValue;
}

@end
