//
//  HomeViewController.m
//  iStep
//
//  Created by Mark on 2019/6/15.
//  Copyright © 2019年 Mark. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MusicCellModel;

@interface MJProductCell : UICollectionViewCell
@property (nonatomic, strong) MusicCellModel *cellModel;
@property (weak, nonatomic) IBOutlet UIImageView *bigImageView;

@property (weak, nonatomic) IBOutlet UIView *circleView; //背景的图片
@end
