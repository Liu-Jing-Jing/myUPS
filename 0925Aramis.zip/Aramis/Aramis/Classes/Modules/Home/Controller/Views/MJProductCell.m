#import "MJProductCell.h"
#import "MusicCellModel.h"
@interface MJProductCell()
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
//#define MJProductCellID @"product"
@end

@implementation MJProductCell

- (void)awakeFromNib
{
    [super awakeFromNib];
//    self.iconView.layer.cornerRadius = 8;
    self.iconView.clipsToBounds = YES;
    self.circleView.layer.cornerRadius = self.circleView.bounds.size.height/2;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self = [[NSBundle mainBundle]loadNibNamed:@"MJProductCell" owner:self options:nil].lastObject;
    }
    return self;
}


- (void)setCellModel:(MusicCellModel *)cellModel
{
    _cellModel = cellModel;
    self.iconView.image = [UIImage imageNamed:cellModel.icon];
    self.nameLabel.text = cellModel.title;
    self.circleView.hidden = !cellModel.selected;
    if([cellModel.title isEqualToString:@"嬉戏"])
    {
        //特殊处理
        self.bigImageView.image = [UIImage imageNamed:cellModel.icon];
        self.iconView.image = nil;
    }
}
@end
