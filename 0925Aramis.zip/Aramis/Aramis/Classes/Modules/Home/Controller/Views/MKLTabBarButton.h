//
//  MKLTabBarButton.h
//  iMusic
//
//  Created by Mark Lewis on 17-5-1.
//  Copyright (c) 2017年 刘竞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MKLTabBarButton : UIButton
@property (nonatomic, strong) UITabBarItem *item;
@end
