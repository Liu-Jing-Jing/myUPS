//
//  RadiusButton.m
//  Aramis
//
//  Created by Mark on 2019/9/8.
//  Copyright © 2019年 Mark. All rights reserved.
//

#import "RadiusButton.h"

@implementation RadiusButton

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    self.layer.cornerRadius = self.frame.size.width/2;
    //NSLog(NSStringFromCGRect(self.frame));
    return self;
}


-(void)awakeFromNib
{
    [super awakeFromNib];
    self.layer.cornerRadius = self.bounds.size.width/2;
}


- (void)layoutSubviews
{
    self.layer.cornerRadius = self.frame.size.width/2;
}
/*
 
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
