//
//  RectButton.h
//  Aramis
//
//  Created by 柏霖尹 on 2019/8/22.
//  Copyright © 2019 Mark. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RectButton : UIButton

@end
