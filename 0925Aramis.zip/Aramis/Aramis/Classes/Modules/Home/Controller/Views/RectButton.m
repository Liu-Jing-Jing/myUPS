//
//  RectButton.m
//  Aramis
//
//  Created by 柏霖尹 on 2019/8/22.
//  Copyright © 2019 Mark. All rights reserved.
//

#import "RectButton.h"

@implementation RectButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self)
    {
        self.layer.cornerRadius = 5;
    }
    return self;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    self.layer.cornerRadius = 5;
}
@end
