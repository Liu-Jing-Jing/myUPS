//
//  Slider.m
//  PuddingLight
//
//  Created by sjty on 2019/6/22.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import "RedSlider.h"
@interface RedSlider()
@property(nonatomic,strong)CAShapeLayer *bgLayer;
@property(nonatomic,strong)CAShapeLayer *colorLayer;
@property(nonatomic,strong)CAShapeLayer *colorbgLayer;
@property(nonatomic,strong)CAGradientLayer *gradientLayer;
@property(nonatomic,strong)UIButton *sliderButton;

@property(nonatomic,strong)CAShapeLayer *circleLayer;
@property(nonatomic,strong)CAGradientLayer *circleGradientLayer;
@end

@implementation RedSlider

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        self.minimumValue=0;
        self.maximumValue=100;
        self.currentValue=0;
        _bgLayer=[[CAShapeLayer alloc] init];
        [self.layer addSublayer:_bgLayer];
        
        _colorbgLayer=[[CAShapeLayer alloc] init];
        [self.layer addSublayer:_colorbgLayer];
        
        _colorLayer=[[CAShapeLayer alloc] init];
        [self.layer addSublayer:_colorLayer];
        
        _gradientLayer=[[CAGradientLayer alloc] init];
        
        [self.layer addSublayer:_gradientLayer];
        _sliderButton=[[UIButton alloc] initWithFrame:CGRectMake(5, 5, 20, 20)];
        [self addSubview:_sliderButton];
        [_sliderButton setImage:[UIImage imageNamed:@"slider_bg_w"] forState:UIControlStateNormal];
        _sliderButton.userInteractionEnabled=NO;
        _circleLayer=[[CAShapeLayer alloc] init];
        [self.layer addSublayer:_circleLayer];
        
        _circleGradientLayer=[[CAGradientLayer alloc] init];
        
        [self.layer addSublayer:_circleGradientLayer];
        [self updateUI];
        
    }
    return self;
    
}




-(void)drawRect:(CGRect)rect{
    
    
    _gradientLayer.frame=CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    _bgLayer.frame=CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    
    _colorbgLayer.frame=CGRectMake(10, 10, self.frame.size.width-20, self.frame.size.height-20);
    
    _colorbgLayer.masksToBounds=YES;
    _colorbgLayer.cornerRadius=_colorbgLayer.frame.size.height/2;
    _colorbgLayer.backgroundColor=[UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1].CGColor;
    
    
    
    
    _bgLayer.masksToBounds=YES;
    _bgLayer.cornerRadius=self.frame.size.height/2;
    _bgLayer.backgroundColor= [UIColor clearColor].CGColor;
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    
    
    _colorLayer.frame=CGRectMake(10, 10, (self.frame.size.width-20)*_currentValue/100.0f, self.frame.size.height-20);
    [CATransaction commit];
    _colorLayer.backgroundColor=[UIColor whiteColor].CGColor;
    _colorLayer.masksToBounds=YES;
    _colorLayer.cornerRadius=self.colorLayer.frame.size.height/2;
#warning 修改为红色的滑动条
    _gradientLayer.colors=@[(__bridge id)JJColor(255, 53, 49).CGColor,
                            (__bridge id)JJColor(255, 53, 49).CGColor,];
    _gradientLayer.locations = @[@(0.0),@(1.0)];
    _gradientLayer.startPoint = CGPointMake(0, 0.5);
    
    _gradientLayer.endPoint   = CGPointMake(1,0.5);
    _gradientLayer.mask=_colorLayer;
    
    float finalx;
    finalx=(self.frame.size.width-20)*_currentValue/100.0f;
    if (finalx<20) {
        finalx=20;
    }
    
    if (finalx>self.frame.size.width-20) {
        finalx=self.frame.size.width-20;
    }
    _sliderButton.center=CGPointMake(finalx, self.center.y-self.frame.origin.y);
#warning x的坐标有问题
}


-(void)setCurrentValue:(float)currentValue{
    _currentValue=currentValue;
    [self setNeedsDisplay];
}

-(void)updateUI{
    
}

-(BOOL) beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    [super beginTrackingWithTouch:touch withEvent:event];
    
    return YES;
}

-(BOOL) continueTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    [super continueTrackingWithTouch:touch withEvent:event];
    
    CGPoint lastPoint = [touch locationInView:self];
    
    [self moveHandle:lastPoint];
    [self sendActionsForControlEvents:UIControlEventValueChanged];
    return YES;
}

-(void)setMaximumValue:(float)maximumValue{
    _maximumValue=maximumValue;
}

-(void)setMinimumValue:(float)minimumValue{
    _minimumValue=minimumValue;
}


-(void)moveHandle:(CGPoint)point {
//    float finalx;
//    finalx=point.x+20;
//    if (finalx<20) {
//        finalx=20;
//    }
//
//    if (finalx>self.frame.size.width-20) {
//        finalx=self.frame.size.width-20;
//    }
//    _sliderButton.center=CGPointMake(finalx, self.center.y-self.frame.origin.y);
    _currentValue =(point.x+10)/(self.frame.size.width-20)*100;
    if(_currentValue<_minimumValue){
        _currentValue=_minimumValue;
    }
    if (_currentValue>_maximumValue) {
        _currentValue=_maximumValue;
    }
   
    [self setNeedsDisplay];
    
    if ([self.delegate respondsToSelector:@selector(slider:SliderValue:)]) {
        // [self.delegate slider:self SliderValue:_currentValue];
        [self.delegate slider:self SliderValue:self.currentValue];
    }
    
    
}

-(void)endTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event{
    [super endTrackingWithTouch:touch withEvent:event];
    
    
}

@end
