//
//  SJTYSliderView.h
//  ColorLightStrip
//
//  Created by sjty on 2019/3/6.
//  Copyright © 2019年 com.sjty. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class SJTYSliderView;

@protocol SJTYSliderViewDelegate <NSObject>

-(void)slider:(SJTYSliderView *)slider sliderValue:(float) value;

@end


@interface SJTYSliderView : UIView

@property(nonatomic,strong)UIImage *leftImage;

@property(nonatomic,strong)UIImage *rightImage;

@property(nonatomic,weak)id<SJTYSliderViewDelegate> delegate;
@property (weak, nonatomic) IBOutlet UISlider *centerSlider;
@end

NS_ASSUME_NONNULL_END
