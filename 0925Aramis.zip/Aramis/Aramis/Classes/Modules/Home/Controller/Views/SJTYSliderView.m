//
//  SJTYSliderView.m
//  ColorLightStrip
//
//  Created by sjty on 2019/3/6.
//  Copyright © 2019年 com.sjty. All rights reserved.
//

#import "SJTYSliderView.h"

@interface SJTYSliderView()
@property(nonatomic,strong)UIView *contentView;
@property (weak, nonatomic) IBOutlet UIButton *leftButton;

@property (weak, nonatomic) IBOutlet UIButton *rightButton;

@end

@implementation SJTYSliderView


- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        [self setupUI];
    }
    return self;
}


-(void)setupUI{
    [self addSubview:self.contentView];
    [self.centerSlider addTarget:self action:@selector(sliderValueChange) forControlEvents:UIControlEventValueChanged];
    [self.leftButton addTarget:self action:@selector(leftAction) forControlEvents:UIControlEventTouchDown];
    
    [self.rightButton addTarget:self action:@selector(rightAction) forControlEvents:UIControlEventTouchDown];
    
    
}


-(void)sliderValueChange{
//    NSLog(@"%f",self.centerSlider.maximumValue);
    if ([self.delegate respondsToSelector:@selector(slider:sliderValue:)]) {
//        NSLog(@"%f",self.centerSlider.value);
        float value=self.centerSlider.value;
        [self.delegate slider:self sliderValue:value];
    }
}


-(void)leftAction{
    self.centerSlider.value-=1;
    if ([self.delegate respondsToSelector:@selector(slider:sliderValue:)]) {
        [self.delegate slider:self sliderValue:self.centerSlider.value];
    }
}


-(void)rightAction{
    self.centerSlider.value+=1;
    if ([self.delegate respondsToSelector:@selector(slider:sliderValue:)]) {
        [self.delegate slider:self sliderValue:self.centerSlider.value];
    }
}



-(void)setLeftImage:(UIImage *)leftImage{
    [self.leftButton setImage:leftImage forState:UIControlStateNormal];
}


-(void)setRightImage:(UIImage *)rightImage{
    [self.rightButton setImage:rightImage forState:UIControlStateNormal];
    
}


-(UIView *)contentView{
    if (!_contentView) {
        _contentView=[[[NSBundle mainBundle] loadNibNamed:@"SJTYSliderView" owner:self options:nil] lastObject];
    }
    return _contentView;
}



-(void)layoutSubviews{
    [super layoutSubviews];
    
    _contentView.frame=self.bounds;
    
    
}
@end
