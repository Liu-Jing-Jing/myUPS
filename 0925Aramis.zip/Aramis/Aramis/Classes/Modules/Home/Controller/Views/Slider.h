//
//  Slider.h
//  PuddingLight
//
//  Created by sjty on 2019/6/22.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class Slider;
@protocol SliderDelegte <NSObject>

-(void)slider:(Slider *)slider SliderValue:(float)sliderValue;

@end

@interface Slider : UIControl

/**
 最小值
 */
@property (nonatomic,assign) float minimumValue;
//
/**
 最大值
 */
@property (nonatomic,assign) float maximumValue;

//当前值
@property (nonatomic,assign) float currentValue;

@property(nonatomic,weak)id<SliderDelegte>delegate;

@end

NS_ASSUME_NONNULL_END
