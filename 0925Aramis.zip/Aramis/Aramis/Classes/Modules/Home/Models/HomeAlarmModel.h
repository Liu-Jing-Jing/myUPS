//
//  HomeAlarmModel.h
//  Aramis
//
//  Created by 柏霖尹 on 2019/8/22.
//  Copyright © 2019 Mark. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface HomeAlarmModel : NSObject
@property (nonatomic, strong) NSDate *alarmDate;
@property (nonatomic, strong) NSString *alarmString;
@property (nonatomic, assign) BOOL isSmartWakeup;
@property (nonatomic, assign) BOOL is;
- (NSString *)convertDateFormatter:(NSDate *)date;

@end

