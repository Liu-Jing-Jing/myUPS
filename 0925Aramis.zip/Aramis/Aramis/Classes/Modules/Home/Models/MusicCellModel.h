//
//  MusicCellModel.h
//  Aramis
//
//  Created by 柏霖尹 on 2019/9/10.
//  Copyright © 2019 Mark. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MusicCellModel : NSObject
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *icon;
@property (nonatomic, assign) BOOL selected;
- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)musicCellModelWithDict:(NSDictionary *)dict;
@end

NS_ASSUME_NONNULL_END
