//
//  MusicCellModel.m
//  Aramis
//
//  Created by 柏霖尹 on 2019/9/10.
//  Copyright © 2019 Mark. All rights reserved.
//

#import "MusicCellModel.h"

@implementation MusicCellModel
- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.icon = dict[@"icon"];
        self.title = dict[@"title"];
        //        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)musicCellModelWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}@end
