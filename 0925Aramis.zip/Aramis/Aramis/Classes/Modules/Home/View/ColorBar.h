//
//  ColorBar.h
//  PuddingLight
//
//  Created by sjty on 2019/6/22.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef enum : NSUInteger {
    ColorBarStyleNormal=1,//可编辑型
    ColorBarStyleEdit,//不可编辑型
} ColorBarStyle;


@class ColorBar;
@protocol ColorBarDelegate <NSObject>

-(void)colorBar:(ColorBar *)colorBar Color:(UIColor *)color  ColorBarStyle:(ColorBarStyle) barStyle ColorIndex:(NSInteger )colorIndex ;

@end


@interface ColorBar : UIView
@property(nonatomic,copy)NSString *title;
//@property(nonatomic,assign)ColorBarStyle barStyle;

@property(nonatomic,strong)NSArray *colorArray;

@property(nonatomic,weak)id<ColorBarDelegate>delegate;

@end

NS_ASSUME_NONNULL_END
