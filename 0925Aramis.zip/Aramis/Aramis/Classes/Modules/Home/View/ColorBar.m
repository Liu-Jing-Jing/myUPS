//
//  ColorBar.m
//  PuddingLight
//
//  Created by sjty on 2019/6/22.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import "ColorBar.h"

@interface ColorBar()
@property(nonatomic,strong)UILabel *titleLabel;
@property(nonatomic,strong)NSArray *colorButtonArray;
@end

@implementation ColorBar

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        self.backgroundColor=[UIColor clearColor];
//        self.barStyle=ColorBarStyleEnable;
        [self setupUI];
    }
    return self;
}


-(void)setupUI{
    _titleLabel=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height/2)];
    [self addSubview:_titleLabel];
    _titleLabel.textColor=[UIColor whiteColor];
    _titleLabel.font=[UIFont systemFontOfSize:15];
    float width=self.frame.size.width;
    float height=self.frame.size.height;
    NSMutableArray *array=[NSMutableArray array];
    int colorCount=6;
    for (int i=0; i<colorCount; i++) {
        UIButton *button=[[UIButton alloc] initWithFrame:CGRectMake(width/7*i+i*width/7/5, height/2+self.frame.size.height/2*1/3/2, width/7, self.frame.size.height/2*2/3)];
        [self addSubview:button];
        button.tag=i;
        [array addObject:button];
//        [button setImage:[UIImage imageNamed:@"select_white"] forState:UIControlStateSelected];
        [self initColor:button];
        [button addTarget:self action:@selector(colorAction:) forControlEvents:UIControlEventTouchDown];
    }
    self.colorButtonArray=array;
}



-(void)colorAction:(UIButton *)colorButton{
     NSInteger tag=colorButton.tag;
    UIColor *bgColor;
    if (tag<=_colorArray.count-1) {
        bgColor=_colorArray[tag];
    }else{
        bgColor=[UIColor clearColor];
    }
    
    
    CGFloat red = 0.0;
    CGFloat green = 0.0;
    CGFloat blue = 0.0;
    CGFloat alpha = 0.0;
    [bgColor getRed:&red green:&green blue:&blue alpha:&alpha];
    colorButton.layer.borderColor=[UIColor colorWithRed:(255-red*255)/255.0f green:(255-green*255)/255.0f blue:(255-blue*255)/255.0f alpha:1].CGColor;
    colorButton.layer.borderWidth=1;
    
    for (int i=0; i<self.colorButtonArray.count; i++) {
        UIButton *button=self.colorButtonArray[i];
        if (tag!=i) {
            [self layerBorderColor:button];
        }
    }
    
    if (red==0&&green==0&&blue==0) {
        if([self.delegate respondsToSelector:@selector(colorBar:Color:ColorBarStyle:ColorIndex:)]){
            [self.delegate colorBar:self Color:bgColor  ColorBarStyle:ColorBarStyleEdit ColorIndex:tag];
        }
    }else{
        if([self.delegate respondsToSelector:@selector(colorBar:Color:ColorBarStyle:ColorIndex:)]){
            [self.delegate colorBar:self Color:bgColor  ColorBarStyle:ColorBarStyleNormal ColorIndex:tag];
        }
    }
}



-(void)layerBorderColor:(UIButton *)colorButton{
    
    NSInteger tag=colorButton.tag;
    UIColor *bgColor;
    if (tag<=_colorArray.count-1) {
        bgColor=_colorArray[tag];
    }else{
        bgColor=[UIColor clearColor];
    }
    
    CGFloat red = 0.0;
    CGFloat green = 0.0;
    CGFloat blue = 0.0;
    CGFloat alpha = 0.0;
    [bgColor getRed:&red green:&green blue:&blue alpha:&alpha];
    if (red==0&&green==0&&blue==0) {
        colorButton.layer.borderColor=[UIColor whiteColor].CGColor;
    }else{
        colorButton.layer.borderColor=bgColor.CGColor;
    }
    
}


-(void)initColor:(UIButton *)colorButton{
    
    colorButton.layer.masksToBounds=YES;
    colorButton.layer.cornerRadius=2.5;
    colorButton.layer.borderColor=[UIColor whiteColor].CGColor;
    colorButton.layer.borderWidth=1;
    [colorButton setTitle:@"+" forState:UIControlStateNormal];
    [colorButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
}



-(void)setColorArray:(NSArray *)colorArray{
    _colorArray=colorArray;
    for (int i=0; i<colorArray.count; i++) {
        UIColor *bgColor=colorArray[i];
        UIButton *colorButton=self.colorButtonArray[i];
        CGFloat red = 0.0;
        CGFloat green = 0.0;
        CGFloat blue = 0.0;
        CGFloat alpha = 0.0;
        [bgColor getRed:&red green:&green blue:&blue alpha:&alpha];
        if (red==0&green==0&blue==0) {
            [colorButton setTitle:@"+" forState:UIControlStateNormal];
            colorButton.layer.borderWidth=1;
        }else{
            
            colorButton.layer.borderWidth=0;
            [colorButton setTitle:@"" forState:UIControlStateNormal];
        }
        colorButton.backgroundColor=bgColor;
        
    }
}



-(void)setTitle:(NSString *)title{
    self.titleLabel.text=title;
}



-(void)layoutSubviews{
    [super layoutSubviews];
    _titleLabel.frame=CGRectMake(0, 0, self.frame.size.width, self.frame.size.height/2);
    float width=self.frame.size.width;
    float height=self.frame.size.height;
    for (int i=0; i<self.colorButtonArray.count; i++) {
        UIButton *button=self.colorButtonArray[i];
        button.frame=CGRectMake(width/7*i+i*width/7/5, height/2+self.frame.size.height/2*1/3/2, width/7, self.frame.size.height/2*2/3);
    }
    
}


@end
