//
//  MusicListViewCell.h
//  Aramis
//
//  Created by 柏霖尹 on 2019/9/11.
//  Copyright © 2019 Mark. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MusicCellModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface MusicListViewCell : UITableViewCell
@property (nonatomic, strong)  MusicCellModel *models;
+(instancetype)cellforTableView:(UITableView *)tableView;
@end

NS_ASSUME_NONNULL_END
