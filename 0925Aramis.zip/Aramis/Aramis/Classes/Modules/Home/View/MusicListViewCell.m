//
//  MusicListViewCell.m
//  Aramis
//
//  Created by 柏霖尹 on 2019/9/11.
//  Copyright © 2019 Mark. All rights reserved.
//

#import "MusicListViewCell.h"
@interface MusicListViewCell()
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@end

@implementation MusicListViewCell
+(instancetype)cellforTableView:(UITableView *)tableView
{
    static NSString *ID = @"MusicListViewCell";
    //1.判断是否存在可重用cell
    MusicListViewCell * cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell)
    {
        //2.为nib文件注册并指定可重用标识
        [tableView registerNib:[UINib nibWithNibName:ID bundle:nil] forCellReuseIdentifier:ID];
        //3.重新获取cell
        cell = [tableView dequeueReusableCellWithIdentifier:ID];
        
    }
    return cell;
}


- (void)setFrame:(CGRect)frame
{
    CGFloat margin = 20;
    CGFloat topMargin = 5;
    //改变frame
    CGRect temp = frame;
    temp.origin.x += margin;
    temp.origin.y += topMargin;
    temp.size.width -= margin*2;
    temp.size.height -= topMargin*2;
    [super setFrame:temp];
}

@end
