//
//  MineViewController.m
//  iStep
//
//  Created by Mark on 2019/6/15.
//  Copyright © 2019年 Mark. All rights reserved.
//

#import "MineViewController.h"

@interface MineViewController ()

@end

@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView *backgroundImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"home_background"]];
    backgroundImage.contentMode = UIViewContentModeScaleToFill;
    backgroundImage.frame = self.tableView.bounds;
    self.tableView.backgroundView = backgroundImage;
}


- (instancetype)init
{
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"MineViewController" bundle:nil];
    return [sb instantiateInitialViewController];
}


#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here, for example:
    // Create the next view controller.
    // Pass the selected object to the new view controller.
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    // Push the view controller.
    //[self.navigationController pushViewController:detailViewController animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
