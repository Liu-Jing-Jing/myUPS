

//
//  HomeLoginViewController.m
//  Natures
//
//  Created by 柏霖尹 on 2019/7/27.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import "HomeLoginViewController.h"
#import "HttpTool.h"
#import "FormTextField.h"
//#import "PWDResetViewController.h"
#import "NSString+BlockExtension.h"
#import "REValidation.h"
#import "TTTAttributedLabel.h"
#define ON @"On"
#define OFF @"Off"
#define kCurrentSignupAccount @"kCurrentSignupCurrent"
#define kCurrentSigup2 @"kCurrentSigup2"
#define kAutoLogin @"autoLogin"   //登录的开关
#define kSavePassword @"kSavePassword"//保存密码的开关
#define kSessionID @"kSessionID"
#import "MainTabBarViewController.h"
@interface HomeLoginViewController ()<TTTAttributedLabelDelegate>
@property (weak, nonatomic) IBOutlet FormTextField *textField1;
@property (weak, nonatomic) IBOutlet FormTextField *textField2;

@property (weak, nonatomic) IBOutlet UIButton *leftButton;
@property (weak, nonatomic) IBOutlet UIButton *rightButton;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@end

@implementation HomeLoginViewController
#warning Lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    // 设置导航栏的东西
    self.navigationItem.leftBarButtonItem = [self itemWithImageName:@"nva_back"
                                                      highImageName:@"nva_back"
                                                             target:self action:@selector(back)];
    //self.title = @"Login";//NSStringLKV(@"Log in");
    //setupUI
    self.textField2.secureTextEntry = YES;
    self.loginButton.layer.cornerRadius = 10.0;
    
    TTTAttributedLabel *label = [[TTTAttributedLabel alloc] initWithFrame:CGRectZero];
    label.textAlignment = NSTextAlignmentCenter;
    label.delegate = self;
    [self.view addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view.mas_left).offset(20);
        make.right.equalTo(self.view.mas_right).offset(-20);
        make.top.equalTo(self.loginButton.mas_bottom).offset(5);
        make.height.mas_equalTo(30.0);
    }];
    
    
#warning bendi
    NSString *content = @"Forgot your Password?";
    label.font = [UIFont systemFontOfSize:11];
    label.numberOfLines = 0;
    label.contentMode = UIViewContentModeCenter;
    label.lineSpacing = 8;
    label.textColor = [UIColor whiteColor];
    label.delegate = self;
    //设置需要点击的文字的颜色大小
    NSMutableAttributedString *mAS = [[NSMutableAttributedString alloc] initWithString:content];
    [label setText:content afterInheritingLabelAttributesAndConfiguringWithBlock:^NSMutableAttributedString *(NSMutableAttributedString *mutableAttributedString) {
        [mutableAttributedString addAttributes:@{NSForegroundColorAttributeName: UIColor.whiteColor, NSFontAttributeName: [UIFont systemFontOfSize:11]} range:[content rangeOfString:content]];
        [mutableAttributedString addAttribute:NSUnderlineStyleAttributeName value:@(1) range:[content rangeOfString:content]];
        return mutableAttributedString;
    }];
    
    label.linkAttributes = @{(NSString *)kCTForegroundColorAttributeName: [UIColor whiteColor]};
    label.inactiveLinkAttributes = @{(NSString *)kCTForegroundColorAttributeName: [UIColor whiteColor]};
    label.activeLinkAttributes = @{(NSString *)kCTForegroundColorAttributeName: [UIColor whiteColor]};
    NSRange selRange=[content rangeOfString:content];
    [label addLinkToTransitInformation:@{@"select":@"policy"} withRange:selRange];
    
#warning 保存密码的具体操作
    // 设置按钮的状态
    NSString *state = [[NSUserDefaults standardUserDefaults] valueForKey:kSavePassword];
    if(state)
    {
        // 设置一下状态
        if ([state isEqualToString:ON]) {
            //设置选择
            self.rightButton.selected = YES;
        }
        else
        {
            self.rightButton.selected = NO;
        }
    }
    
    self.textField1.text = @"tt@txt.tt";
    self.textField2.text = @"666666";
}

- (void)attributedLabel:(TTTAttributedLabel *)label didSelectLinkWithTransitInformation:(NSDictionary *)components
{
    // 跳转到修改密码的页面,但是要判断这个Email是否存在
#warning 25-修改限制长度
    NSString *emailStr = [self.textField1.text trimeLeftAndRightWhitespace];
    NSArray *errors = [REValidation validateObject:emailStr name:@"Email" validators:@[ @"presence", @"length(3, 20)", @"email"]];
    for (NSError *error in errors) NSLog(@"Error: %@", error.localizedDescription);
    
    if(errors.count)
    {        // 提示用户
        NSString *msg = @"请输入正确的邮箱";
        UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:msg message:nil preferredStyle:UIAlertControllerStyleAlert];
        [alertVC addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:NULL]];
    }
    else
    {
//        PWDResetViewController *resetVC = [[PWDResetViewController alloc] init];
//        [self.navigationController pushViewController:resetVC animated:YES];
    }
}



- (IBAction)loginActionButton:(id)sender
{
//    NSString *param1 = @"2333@qq.com";
//    NSString *param2 = @"123456";
    [HttpTool upsLoginAction:^(BOOL state, NSString * _Nonnull message) {
        if(state)
        {
            NSLog(@"成功登录");
            //登录成功之后的页面哦
            [[UIApplication sharedApplication] keyWindow].rootViewController = [[MainTabBarViewController alloc] init];
        }
        else
        {
            [MBProgressHUD showError:message];
        }
        
    }];
    
    if(self.leftButton.selected)
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"On" forKey:kAutoLogin];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"Off" forKey:kAutoLogin];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    if(self.rightButton.selected)
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"On" forKey:kSavePassword];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"Off" forKey:kSavePassword];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    

}

- (IBAction)leftButtonClick:(UIButton *)sender
{
    sender.selected = !sender.isSelected;
    if(sender.isSelected)
    {
        self.rightButton.selected = YES;

#warning 自动登录的处理f过程
        [[NSUserDefaults standardUserDefaults] setObject:@"On" forKey:kAutoLogin];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"Off" forKey:kAutoLogin];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}


- (IBAction)rightButtonClick:(UIButton *)sender
{
    sender.selected = !sender.isSelected;
    
    if(sender.selected)
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"On" forKey:kSavePassword];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"Off" forKey:kSavePassword];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
    }
#warning 记住密码的处理
}


- (void)back
{
#warning 这里用的是self
    [self dismissViewControllerAnimated:NO completion:^{}];
}

- (UIBarButtonItem *)itemWithImageName:(NSString *)imageName highImageName:(NSString *)highImageName target:(id)target action:(SEL)action
{
    UIButton *button = [[UIButton alloc] init];
    [button setBackgroundImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:highImageName] forState:UIControlStateHighlighted];
    [button setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 20)];
    
    
    // 设置按钮的尺寸为背景图片的尺寸
    button.size = button.currentBackgroundImage.size;
    
    // 监听按钮点击
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return [[UIBarButtonItem alloc] initWithCustomView:button];
}


@end
