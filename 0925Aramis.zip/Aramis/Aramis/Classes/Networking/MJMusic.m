//
//  MJMusic.m
//  预习-03-音乐播放器
//
//  Created by MJ Lee on 14-6-3.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import "MJMusic.h"

@implementation MJMusic

@end
