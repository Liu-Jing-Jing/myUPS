//
//  HttpTool.h
//  junhua
//
//  Created by sjty on 2019/7/24.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@class UpsModel, MessageModel;
@interface HttpTool : NSObject
+(instancetype)shareInstance;

-(void)login:(NSString *)email Password:(NSString *)password Block:(void(^)(NSDictionary *  dictionary)) block;

-(void)getCode:(NSString *)email Block:(void(^)(NSDictionary * dictionary)) block;

-(void)registerUser:(NSString *)email Password:(NSString *)password Code:(NSString *)code Block:(void(^)(NSDictionary * dictionary)) block;
+ (void)modifyUserName:(NSString *)newName success:(void (^)(id responseObject)) success failure:(void (^)(NSError *error)) failure;

/**
 应急电源用户的注册和登录
 @param email 1
 @param firstAndLastName 拼接号的名字
 @param password 密码
 @param code 验证码
 @param block 返回结果的回调
 */
-(void)registerUser:(NSString *)email withName:(NSString *)firstAndLastName Password:(NSString *)password Code:(NSString *)code Block:(void (^)(NSDictionary * dictionary))block;
-(void)devicePassword:(NSArray *)macArray Password:(NSString *)password Block:(void(^)(NSDictionary * dictionary)) block;



/**
 忘记设备的密码
 @param macArray Mac列表里的数据
 @param block 成功的毁掉
 */
- (void)getFogetDevicePasswordCode:(NSArray *)macArray Block:(void(^)(NSDictionary * dictionary)) block;
- (void)forgetDevicePassword:(NSString *)code Password:(NSString *)password Block:(void(^)(NSDictionary * dictionary)) block;
- (void)checkPassword:(NSString *)mac Password:(NSString *)password Block:(void(^)(NSDictionary * dictionary)) block;
- (void)changePasswordUsingEmail:(NSString *)email newPassword:(NSString *)password Code:(NSString *)code Block:(void (^)(NSDictionary * _Nonnull))block;
/**
 应急电源测试账号登录 返回是否成功
 */
+ (void)addUPSSignleData:(NSString *)str;
+ (void)getUpsRangeDataWithStartDate:(NSDate *)start endDate:(NSDate *)endDate success:(void (^)(id response))success failure:(void (^)(NSError * error))failure;
+ (void)getUpsDateByYYYYstring:(NSString *)yyyy success:(void (^)(NSArray *response))success failure:(void (^)(NSError * error))failure;

+ (void)upsLoginAction:(void(^)(BOOL state, NSString *message))resultBlock;
/**Current 验证Session是否过期*/
+(void)checkSessionVerify:(void (^)(BOOL))resultBlock failure:(void (^)(NSError * error))failureBlock;
// 注销当前登陆的用户
+ (void)logoutSessionAction:(void(^)(BOOL))resultBlock failure:(void (^)(NSError * error))failureBlock;

/**
 
 Current zh登录账号的个人信息
 @param resultBlock 成功的回调信息数据
 */
+ (void)currentUserInformationWithSessionAction:(void(^)(BOOL state, NSDictionary *data))resultBlock;
+ (void)uploadFile_SessionWithURL:(NSString *)url params:(NSDictionary *)params formDataArray:(NSArray *)formDataArray success:(void (^)(id response))success failure:(void (^)(NSError * error))failure;

/* 这个是Put上传图片的方法*/
+ (void)PUT:(NSString *)URLString data:(NSData *)data parameters:(NSDictionary *)parameters success:(void (^)(id response))success failure:(void (^)(NSError * error))failure;
+ (void)uploadPUT:(NSString *)URLString data:(NSData *)data parameters:(NSDictionary *)parameters success:(void (^)(id response))success failure:(void (^)(NSError * error))failure;
+ (void)uploadIconImage:(UIImage *)image success:(void (^)(id response))success failure:(void (^)(NSError * error))failure;
+ (void)uploadPUT:(NSString *)URLString parameters:(NSDictionary *)parameters success:(void (^)(id response))success failure:(void (^)(NSError * error))failure;

+ (void)getUpsMessageListSuccess:(void (^)(id responseObject)) success failure:(void (^)(NSError *error, NSDictionary *message)) failure;
+(void)upsAddNewMessageMode:(NSArray<MessageModel *> *)modelArray success:(void (^)(id responseObject)) success failure:(void (^)(NSError *error, NSDictionary *message)) failure;
+ (void)postUPSDataToServer:(UpsModel *)model success:(void (^)(NSArray *response))success failure:(void (^)(NSError * error))failure;
@end

/**
 *  用来封装文件数据的模型
 */
@interface HTTPFormData : NSObject
/**
 *  文件数据
 */
@property (nonatomic, strong) NSData *data;

/**
 *  参数名
 */
@property (nonatomic, copy) NSString *name;

/**
 *  文件名
 */
@property (nonatomic, copy) NSString *filename;

/**
 *  文件类型
 */
@property (nonatomic, copy) NSString *mimeType;
+ (HTTPFormData *)instanceWithFileData:(NSData *)data name:(NSString *)name fileName:(NSString *)fileName mineType:(NSString *)mineType;
@end
NS_ASSUME_NONNULL_END
