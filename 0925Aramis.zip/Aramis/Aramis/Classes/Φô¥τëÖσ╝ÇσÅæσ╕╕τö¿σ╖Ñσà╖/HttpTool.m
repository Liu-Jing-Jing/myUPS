//
//  HttpTool.m
//  junhua
//
//  Created by sjty on 2019/7/24.
//  Copyright © 2019 com.sjty. All rights reserved.
//
#import "SVProgressHUD.h"
#import "HttpTool.h"
#import "AFNetworking.h"
#import "UpsModel.h"
#import "MessageModel.h"
#import <CoreTelephony/CTCellularData.h>
#define Host @"http://app.f-union.com"//@"http://sjtyservice.shfch.net" //http://app.f-union.com/
#define TIMEOUT @"Request timed out, please try again later"
#define NONETWORK  @"No network, please check the network"
#define ERROR @"Request failed, try again later"
#define PRODUCTID @(1147401843442315265)
#define FileHost @"http://app.shfch.net/webFile/file/"
#import "NSDate+Helper.h"
NSString * const responseSuccess[2] =
{
    @"200",
    @"201"
};
NSString * const responseError[3] =
{
    @"300",
    @"301",
    @"302"
};
static HttpTool *httpToolInstance = nil;
@interface HttpTool()
@property(nonatomic)NSURLSessionDataTask *task;
@end
@implementation HttpTool
+(instancetype)shareInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (httpToolInstance == nil) {
            httpToolInstance = [[self alloc]init];
            [httpToolInstance loadNetwork];
        }
    });
    return httpToolInstance;
}

-(void)loadNetwork
{
//    [self loadHtml];
    CTCellularData *cellularData = [[CTCellularData alloc]init];
    cellularData.cellularDataRestrictionDidUpdateNotifier = ^(CTCellularDataRestrictedState state) {
        //获取联网状态
        switch (state) {
            case kCTCellularDataRestricted:
                [self loadHtml];
                break;
            case kCTCellularDataNotRestricted:
                // 没有网络的时候提示用户
                break;
            case kCTCellularDataRestrictedStateUnknown:
                
                break;
            default:
                break;
        };
    };
}


-(void)loadHtml{
    
    NSURL *url = [NSURL URLWithString:@"http://sjtyservice.shfch.net"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration] delegate:nil delegateQueue:[NSOperationQueue mainQueue]];
    
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request];
    [dataTask resume];
}
#pragma mark - SJTY session 通用接口
-(void)postRequest:(NSString *)URLString  parameters:(id)parameters success:(void (^)(id responseObject)) success failure:(void (^)(NSError *error)) failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", nil];
    manager.requestSerializer.timeoutInterval = 5.0f;
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    _task =[manager POST:URLString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSHTTPURLResponse *httpURLResponse = (NSHTTPURLResponse*)task.response;
        NSDictionary *dictTTTTTEMP = httpURLResponse.allHeaderFields;
        
        [[NSUserDefaults standardUserDefaults] setObject:[[dictTTTTTEMP valueForKey:@"Set-Cookie"] substringWithRange:NSMakeRange(11, [[dictTTTTTEMP valueForKey:@"Set-Cookie"] rangeOfString:@";"].location-11)] forKey:@"SessionID"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        if (success) {
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    
}
-(void)postWithSessionRequest:(NSString *)URLString  parameters:(id)parameters success:(void (^)(id responseObject)) success failure:(void (^)(NSError *error)) failure{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json",nil];
    
    manager.requestSerializer.timeoutInterval = 5.0f;
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]!=nil)
    {
        NSString *cookieStr = [NSString stringWithFormat:@"JSESSIONID=%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]];
        [manager.requestSerializer setValue:cookieStr forHTTPHeaderField:@"Cookie"];
    }
    
    NSLog(@"发送了POST %@-------params:%@", URLString, parameters);
    _task =[manager POST:URLString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (success) {
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

-(void)getRequest:(NSString *)URLString  parameters:(NSDictionary *)parameters success:(void (^)(id responseObject)) success failure:(void (^)(NSError *error)) failure{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.responseSerializer = [AFJSONResponseSerializer new];
    [manager.requestSerializer setHTTPShouldHandleCookies:YES];
    
    
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet
                                                         setWithObject:@"application/json"];
    
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.requestSerializer.timeoutInterval = 5.0f;
    
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]!=nil)
    {
        NSString *cookieStr = [NSString stringWithFormat:@"JSESSIONID=%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]];
        [manager.requestSerializer setValue:cookieStr forHTTPHeaderField:@"Cookie"];
    }
    
    
    _task =[manager GET:URLString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (success) {
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

-(void)deleteRequest:(NSString *)URLString  parameters:(NSDictionary *)parameters success:(void (^)(id responseObject)) success failure:(void (^)(NSError *error)) failure{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.responseSerializer = [AFJSONResponseSerializer new];
    [manager.requestSerializer setHTTPShouldHandleCookies:YES];
    
    
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet
                                                         setWithObject:@"application/json"];
    
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.requestSerializer.timeoutInterval = 5.0f;
    
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    
    
    
    _task =[manager DELETE:URLString parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (success) {
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}


#pragma mark - 用户账号密码相关的模块
-(void)login:(NSString *)email Password:(NSString *)password Block:(void(^)(NSDictionary * dictionary)) block
{
    NSString *url=[NSString stringWithFormat:@"%@/sjtyApi/app/login?contactKey=%@&password=%@&productId=%ld",Host,email,password,PRODUCTID.longValue];
//#warning 要修改的部分
//    NSDictionary *params = @{@"contactKey": email, @"password":password, @"productId": [NSString stringWithFormat:@"%@", PRODUCTID]};
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:email forKey:@"contactKey"];
    [params setObject:password forKey:@"password"];
    [params setObject:PRODUCTID forKey:@"productId"];
    
    [self postRequest:url parameters:params success:^(id responseObject) {
        NSDictionary *dict;
        if ([[responseObject valueForKey:@"status"] integerValue]==201) {
            dict=@{@"status":[responseObject valueForKey:@"status"],
                   @"message":[responseObject valueForKey:@"message"]
                   };
            [[NSUserDefaults standardUserDefaults] setObject: [responseObject valueForKey:@"data"] forKey:@"SessionID"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
        }else if ([[responseObject valueForKey:@"status"] integerValue]==300){
            dict=@{@"status":[responseObject valueForKey:@"status"],
                   @"message":@"Login failed, account or password is incorrect"
                   };
        }
        if (block) {
            block(dict);
        }
    } failure:^(NSError *error) {
        NSDictionary *dict;
        if (error.code==-1001) {
            dict=@{@"status":@"-1001",
                   @"message":TIMEOUT
                   };
        }else if (error.code==-1009) {
            dict=@{@"status":@"-1009",
                   @"message":NONETWORK
                   };
        }else{
            dict=@{@"status":@"-1001",
                   @"message":ERROR
                   };
        }
        if (block) {
            block(dict);
        }
    }];
}

-(void)registerUser:(NSString *)email withName:(NSString *)firstAndLastName Password:(NSString *)password Code:(NSString *)code Block:(void (^)(NSDictionary * dictionary))block{
    NSString *url=[NSString stringWithFormat:@"%@/sjtyApi/app/loginAndReg",Host];
    NSDictionary *dict=@{@"contactKey":email,
                         @"password":password,
                         @"code":code,
                         @"productId":PRODUCTID,
                         @"name": firstAndLastName
                         };
    [self postWithSessionRequest:url parameters:dict success:^(id responseObject) {
        
        NSLog(@"%@", responseObject);
        if ([[responseObject valueForKey:@"status"] integerValue]==201)
        {
            [[NSUserDefaults standardUserDefaults] setObject: [responseObject valueForKey:@"data"] forKey:@"SessionID"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        if (block)
        {
            
            NSDictionary *dict;
            if ([[responseObject valueForKey:@"status"] integerValue]==201) {
                dict=@{@"status":[responseObject valueForKey:@"status"],
                       @"message":[responseObject valueForKey:@"message"]
                       };
            }else if ([[responseObject valueForKey:@"status"] integerValue]==201){
                dict=@{@"status":[responseObject valueForKey:@"status"],
                       @"message":[responseObject valueForKey:@"message"]
                       };
            }
            
            block(dict);
        }
    } failure:^(NSError *error) {
        NSDictionary *dict;
        if (error.code==-1001) {
            dict=@{@"status":@"-1001",
                   @"message":TIMEOUT
                   };
        }else if (error.code==-1009) {
            dict=@{@"status":@"-1009",
                   @"message":NONETWORK
                   };
        }else{
            dict=@{@"status":@"-1001",
                   @"message":ERROR
                   };
        }
        
        if (block) {
            block(dict);
        }
    }];
}
//y蔡工的注册模块
-(void)orgRegisterUser2:(NSString *)email Password:(NSString *)password Code:(NSString *)code Block:(void (^)(NSDictionary * dictionary))block{
    NSString *url=[NSString stringWithFormat:@"%@/sjtyApi/app/loginAndReg",Host];
    NSDictionary *dict=@{@"contactKey":email,
                         @"password":password,
                         @"code":code,
                         @"productId":PRODUCTID
                         };
    NSString *str = @"\{\"code\": \"0000\",\"contactKey\": \"1515352281@qq.com\",\"password\": \"111111\",\"productId\": 1147401843442315265}";
    NSLog(@"%@\n", str);
    //dict = @{@"clientUserLoginVo": @"\{\"code\": \"0000\",\"contactKey\": \"1515352281@qq.com\",\"password\": \"111111\",\"productId\": 1147401843442315265}"};
    [self postWithSessionRequest:url parameters:dict success:^(id responseObject) {
        
        NSLog(@"%@", responseObject);
        if ([[responseObject valueForKey:@"status"] integerValue]==201) {
            [[NSUserDefaults standardUserDefaults] setObject: [responseObject valueForKey:@"data"] forKey:@"SessionID"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        if (block) {
            
            NSDictionary *dict;
            if ([[responseObject valueForKey:@"status"] integerValue]==201) {
                dict=@{@"status":[responseObject valueForKey:@"status"],
                       @"message":[responseObject valueForKey:@"message"]
                       };
            }else if ([[responseObject valueForKey:@"status"] integerValue]==201){
                dict=@{@"status":[responseObject valueForKey:@"status"],
                       @"message":[responseObject valueForKey:@"message"]
                       };
            }
            
            block(dict);
        }
    } failure:^(NSError *error) {
        NSDictionary *dict;
        if (error.code==-1001) {
            dict=@{@"status":@"-1001",
                   @"message":TIMEOUT
                   };
        }else if (error.code==-1009) {
            dict=@{@"status":@"-1009",
                   @"message":NONETWORK
                   };
        }else{
            dict=@{@"status":@"-1001",
                   @"message":ERROR
                   };
        }
        if (block) {
            block(dict);
        }
    }];
}

/**  修改密码  @param email 需要修改的账号  @param password 新密码  @param code 需要提前发送验证码  @param block 成功后的回调*/
- (void)changePasswordUsingEmail:(NSString *)email newPassword:(NSString *)password Code:(NSString *)code Block:(void (^)(NSDictionary * _Nonnull))block{
    NSString *url=[NSString stringWithFormat:@"%@/sjtyApi/app/updatePwdByCode?contactKey=%@&newPwd=%@&code=%@&productId=%ld",Host,email,password,code,PRODUCTID.longValue];
    NSDictionary *dict=@{};
    
    [self postWithSessionRequest:url parameters:dict success:^(id responseObject) {
        
        if ([[responseObject valueForKey:@"status"] integerValue]==200) {
            if (block) {
                NSDictionary *dict=@{@"status":[responseObject valueForKey:@"status"],
                                    @"message":[responseObject valueForKey:@"message"]
                                    };
                block(dict);
            }
//            [[NSUserDefaults standardUserDefaults] setObject: [responseObject valueForKey:@"data"] forKey:@"SessionID"];
//            [[NSUserDefaults standardUserDefaults] synchronize];
        }else{
            if (block) {
                
                NSDictionary *dict;
                if ([[responseObject valueForKey:@"status"] integerValue]==201) {
                    dict=@{@"status":[responseObject valueForKey:@"status"],
                           @"message":[responseObject valueForKey:@"message"]
                           };
                }else if ([[responseObject valueForKey:@"status"] integerValue]==201){
                    dict=@{@"status":[responseObject valueForKey:@"status"],
                           @"message":[responseObject valueForKey:@"message"]
                           };
                }
                
                block(dict);
            }
        }
        
    } failure:^(NSError *error) {
        NSDictionary *dict;
        if (error.code==-1001) {
            dict=@{@"status":@"-1001",
                   @"message":TIMEOUT
                   };
        }else if (error.code==-1009) {
            dict=@{@"status":@"-1009",
                   @"message":NONETWORK
                   };
        }else{
            dict=@{@"status":@"-1001",
                   @"message":ERROR
                   };
        }
        if (block) {
            block(dict);
        }
    }];
    
}

/**第一个参数是邮箱 Email告诉我 @param email 第一个参数是邮箱  @param block 返回成功*/
- (void)getCode:(NSString *)email Block:(void (^)(NSDictionary * dictionary))block{
    
    NSString *url=[NSString stringWithFormat:@"%@/sjtyApi/app/sendCode_1?contactKey=%@&productId=%ld&language=en_US&simulation=1",Host,email, PRODUCTID.longValue];
    
    //NSString * url = [NSString stringWithFormat:@"%@/sjtyApi/app/sendCode_1",Host];
    //NSDictionary *dict=@{@"contactKey": email, @"productId" : PRODUCTID, @"language": @"en_US", @"simulation": @"1"};
    [self postRequest:url parameters:nil success:^(id responseObject)
     {
         
         NSLog(@"%@", responseObject);
         if ([[responseObject objectForKey:@"status"] integerValue]==200)
         {
             if (block)
             {
                 NSDictionary *dic=@{@"status":[responseObject objectForKey:@"status"]};
                 block(dic);
             }
         }
     } failure:^(NSError *error) {
         NSDictionary *dict;
         if (error.code==-1001)
         {
             dict=@{@"status":@"-1001",
                    @"message":TIMEOUT
                    };
         }else if (error.code==-1009)
         {
             dict=@{@"status":@"-1009",
                    @"message":NONETWORK
                    };
         }
         else
         {
             dict=@{@"status":@"-1001",
                    @"message":ERROR
                    };
         }
         if (block) {
             block(dict);
         }
     }];
}




-(NSString*)DataTOjsonString:(id)object
{
    NSString *jsonString = nil;
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:object
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    if (! jsonData) {
        NSLog(@"Got an error: %@", error);
    } else {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    return jsonString;
}


+(void)checkSessionVerify:(void (^)(BOOL))resultBlock failure:(void (^)(NSError * error))failureBlock
{
    __block BOOL flag = NO;
    NSString *urlString  = [NSString stringWithFormat:@"%@/sjtyApi/app/checkSession", Host];
    [[HttpTool shareInstance] postWithSessionRequest:urlString parameters:nil success:^(id responseObject) {
        int code = [responseObject[@"status"] intValue];
        
        NSLog(@"Session =======%d", code);
        
        if(code == 201 || code == 200)
        {
            flag = YES;
            //            成功
            if(resultBlock)
            {
                resultBlock(flag);
            }
        }
        else
        {
            flag = NO;
            // 重进入登录界面
            if(resultBlock)
            {
                resultBlock(flag);
            }
        }
    } failure:^(NSError *error) {
#warning 错误处理的地方
        if(failureBlock)
        {
            failureBlock(error);
        }
        
    }];
    //没有失效
    //错误处理
}

+ (void)logoutSessionAction:(void(^)(BOOL))resultBlock  failure:(void (^)(NSError * error))failureBlock
{
    __block BOOL flag = NO;
    NSString *urlStr = [NSString stringWithFormat:@"%@/sjtyApi/app/logout", Host];
    [[HttpTool shareInstance] postWithSessionRequest:urlStr parameters:nil success:^(id responseObject) {
        int code = [responseObject[@"status"] intValue];
        
        NSLog(@"Logout Session =======%d", code);
        
        if(code == 201 || code == 200)
        {
            flag = YES;
            //            成功
            if(resultBlock)
            {
                resultBlock(flag);
            }
        }
        else
        {
            flag = NO;
            // 重进入登录界面
            if(resultBlock)
            {
                resultBlock(flag);
            }
        }
    } failure:^(NSError *error) {
#warning 错误处理的地方
        //没有失效
        //错误处li
        
    }];
    
}
// 先获得验证码
+ (void)modifyUserName:(NSString *)newName success:(void (^)(id responseObject)) success failure:(void (^)(NSError *error)) failure
{
    NSString *urlString=[NSString stringWithFormat:@"%@/sjtyApi/app/clientUser/update",Host];
    
    [HttpTool uploadPUT:urlString parameters:@{@"username": newName} success:^(id  _Nonnull response) {
        //修改成功
        if(success)
        {
            success(response);
        }
    } failure:^(NSError * _Nonnull error) {
        if(failure)
        {
            failure(error);
        }
    }];
}
#pragma mark - 设置蓝牙模块的网络请求 Mac参数相关的URL
//设置蓝牙设备密码
-(void)devicePassword:(NSArray *)macArray Password:(NSString *)password Block:(void (^)(NSDictionary * dictionary))block{
    NSString *url=[NSString stringWithFormat:@"%@/sjtyApi/app/distributorMac/addBatch",Host];
    NSMutableArray *array=[NSMutableArray array];
    for (int i=0; i<macArray.count; i++) {
        NSDictionary *dict=@{@"mac":macArray[i],
                             @"password":password
                             };
        [array addObject:dict];
    }
//    NSDictionary *dict=@{@"macPwds":array};
    
//    NSString *s=[self DataTOjsonString:dict];
    
    [self postWithSessionRequest:url parameters:array success:^(id responseObject) {
        if ([[responseObject objectForKey:@"status"] integerValue]==200) {
           
            if (block) {
                block(responseObject);
            }
        }else{
            if (block) {
                block(responseObject);
            }
        }
    } failure:^(NSError *error) {
        NSDictionary *dict;
        if (error.code==-1001) {
            dict=@{@"status":@"-1001",
                   @"message":TIMEOUT
                   };
        }else if (error.code==-1009) {
            dict=@{@"status":@"-1009",
                   @"message":NONETWORK
                   };
        }else{
            dict=@{@"status":@"-1001",
                   @"message":ERROR
                   };
        }
        if (block) {
            block(dict);
        }
    }];
}
-(void)checkPassword:(NSString *)mac Password:(NSString *)password Block:(void (^)(NSDictionary * _Nonnull))block{
    NSString *url=[NSString stringWithFormat:@"%@/sjtyApi/app/distributorMac/checkPwd",Host];
    NSMutableArray *array=[NSMutableArray array];
    NSDictionary *dicts=@{@"mac":mac,
                         @"password":password
                         };
    [array addObject:dicts];
//    NSDictionary *dict=@{@"macPwds":array};
    
    [self postWithSessionRequest:url parameters:array success:^(id responseObject) {
        if ([[responseObject objectForKey:@"status"] integerValue] ==200) {
            if (block ) {
                block(responseObject);
            }
        }else{
            if (block ) {
                block(responseObject);
            }
        }
    } failure:^(NSError *error) {
        NSDictionary *dict;
        if (error.code==-1001) {
            dict=@{@"status":@"-1001",
                   @"message":TIMEOUT
                   };
        }else if (error.code==-1009) {
            dict=@{@"status":@"-1009",
                   @"message":NONETWORK
                   };
        }else{
            dict=@{@"status":@"-1001",
                   @"message":ERROR
                   };
        }
        if (block) {
            block(dict);
        }
    }];
}
-(void)getFogetDevicePasswordCode:(NSArray *)macArray Block:(void (^)(NSDictionary * _Nonnull))block{
    NSMutableString *macString=[NSMutableString string];
    
    for (int i=0; i<macArray.count; i++)
    {
        if (i==0) {
            [macString appendString:macArray[i]];
        }else{
            [macString appendString:[NSString stringWithFormat:@",%@",macArray[i]]];
        }
        
    }
    NSDictionary *dict=@{};
    NSString *url=[NSString stringWithFormat:@"%@/sjtyApi/app/distributorMac/sendCode?macs=%@&language=en_US&simulation=1",Host,macString];
    
    [self postWithSessionRequest:url parameters:dict success:^(id responseObject) {
        
        if ([[responseObject objectForKey:@"status"] integerValue]==200) {
            if (block) {
                NSDictionary *dic=@{@"status":[responseObject objectForKey:@"status"]};
                block(dic);
            }
        }else{
            
        }
    } failure:^(NSError *error) {
        NSDictionary *dict;
        if (error.code==-1001) {
            dict=@{@"status":@"-1001",
                   @"message":TIMEOUT
                   };
        }else if (error.code==-1009) {
            dict=@{@"status":@"-1009",
                   @"message":NONETWORK
                   };
        }else{
            dict=@{@"status":@"-1001",
                   @"message":ERROR
                   };
        }
        if (block) {
            block(dict);
        }
    }];
}
-(void)forgetDevicePassword:(NSString *)code Password:(NSString *)password Block:(void (^)(NSDictionary * _Nonnull))block{
    NSDictionary *dict=@{};
    NSString *url=[NSString stringWithFormat:@"%@/sjtyApi/app/distributorMac/updatePwd?code=%@&password=%@",Host,code,password];
    
    [self postWithSessionRequest:url parameters:dict success:^(id responseObject) {
        
        if ([[responseObject objectForKey:@"status"] integerValue]==200) {
            if (block) {
                NSDictionary *dic=@{@"status":[responseObject objectForKey:@"status"]};
                block(dic);
            }
        }else{
            block(responseObject);
        }
    } failure:^(NSError *error) {
        NSDictionary *dict;
        if (error.code==-1001) {
            dict=@{@"status":@"-1001",
                   @"message":TIMEOUT
                   };
        }else if (error.code==-1009) {
            dict=@{@"status":@"-1009",
                   @"message":NONETWORK
                   };
        }else{
            dict=@{@"status":@"-1001",
                   @"message":ERROR
                   };
        }
        if (block) {
            block(dict);
        }
    }];
}

#warning 用户信息模块
+ (void)currentUserInformationWithSessionAction:(void(^)(BOOL state, NSDictionary *data))resultBlock
{
    __block BOOL flag = NO;
    
    NSString *urlStr = [NSString stringWithFormat:@"%@/sjtyApi/app/clientUser/getSelfInfo", Host];
    [[HttpTool shareInstance] getRequest:urlStr
                              parameters:nil
                                 success:^(id responseObject) {
                                     //
                                     int code = [responseObject[@"status"] intValue];
                                     if(code == 201 || code == 200)
                                     {
                                         flag = YES;
                                         //            成功
                                         if(resultBlock)
                                         {
                                             resultBlock(flag, responseObject[@"data"]);
                                         }
                                     }
                                     else
                                     {
                                         flag = NO;
                                         // 重进入登录界面
                                         if(resultBlock)
                                         {
                                             resultBlock(flag, responseObject[@"data"]);
                                         }
                                     }
                                     NSLog(@"User Info Data = %@", responseObject[@"data"]);
                                     
                                     
                                 } failure:^(NSError *error) {
#warning  错误的处理方法
                                 }];
}
#pragma mark - PUT请求的多种可用方法
// SJTY可用的PUT 上传数据的方法
+ (void)PUT:(NSString *)URLString data:(NSData *)data parameters:(NSDictionary *)parameters success:(void (^)(id response))success failure:(void (^)(NSError * error))failure {
    
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    NSMutableURLRequest *request = [[AFJSONRequestSerializer serializer] multipartFormRequestWithMethod:@"PUT" URLString:URLString parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        if (data) {
            [formData appendPartWithFileData:data name:@"file" fileName:@"userAvatar.png" mimeType:@"image/png"];
        }
    } error:nil];
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]!=nil)
    {
        NSString *cookieStr = [NSString stringWithFormat:@"JSESSIONID=%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]];
        [manager.requestSerializer setValue:cookieStr forHTTPHeaderField:@"Cookie"];
    }
    //        [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    if (parameters && parameters.count > 0) {
        [request setHTTPBody:[NSJSONSerialization dataWithJSONObject:parameters options:NSJSONWritingPrettyPrinted error:nil]];
    }
    __block NSURLSessionDataTask *task;
    task = [manager uploadTaskWithStreamedRequest:request progress:NULL completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        NSLog(@"UPLOAD success  ------%@", responseObject[@"message"]);
        if(success)
        {
            success(responseObject);
        }
    }];
    
    [task resume];
    //        __block NSURLSessionDataTask *task;
    //        task = [manager uploadTaskWithStreamedRequest:request progress:^(NSProgress * _Nonnull uploadProgress) {
    //        } completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
    //
    //            if (!error) {
    //                NSLog(@"UPLOAD success  ------%@", responseObject[@"message"]);
    ////                [self requestSuccessWithSessionDataTask:task responseObject:responseObject success:success failure:failure];
    //            } else {
    ////                [self requestFailureWithSessionDataTask:task error:error failure:failure];
    //            }
    //        }];
    //        [task resume];
}
+ (void)uploadFile_SessionWithURL:(NSString *)url params:(NSDictionary *)params formDataArray:(NSArray *)formDataArray success:(void (^)(id response))success failure:(void (^)(NSError * error))failure
{
    // AFNetWorking
    // 创建请求管理对象
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json",nil];
    
    manager.requestSerializer.timeoutInterval = 5.0f;
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]!=nil)
    {
        NSString *cookieStr = [NSString stringWithFormat:@"JSESSIONID=%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]];
        [manager.requestSerializer setValue:cookieStr forHTTPHeaderField:@"Cookie"];
    }
    
    // 发送请求
    [manager POST:url parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull allFormData) {
        for (HTTPFormData *formData in formDataArray) {
            [allFormData appendPartWithFileData:formData.data name:formData.name fileName:formData.filename mimeType:formData.mimeType];
        }
        //
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        // 上传进度
        //[SVProgressHUD showProgress:uploadProgress.fractionCompleted status:@"Uploading"];
    
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if(success)
        {
            NSLog(@"upload file--%@", responseObject);
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if(failure)
        {
            failure(error);
        }
    }];
    
}
+ (void)uploadPUT:(NSString *)URLString parameters:(NSDictionary *)parameters success:(void (^)(id response))success failure:(void (^)(NSError * error))failure;
{
    // 创建请求管理对象
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json",nil];
    
    manager.requestSerializer.timeoutInterval = 5.0f;
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]!=nil)
    {
        NSString *cookieStr = [NSString stringWithFormat:@"JSESSIONID=%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]];
        [manager.requestSerializer setValue:cookieStr forHTTPHeaderField:@"Cookie"];
    }
    [manager PUT:URLString parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"发送了PUT请求-----%@", responseObject[@"message"]);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
    
}
- (void)uploadFileUseRESTWithURLString:(NSString *)URLString rename:(NSString *)rename fromFile:(NSURL *)fileURL orFromData:(NSData *)data progress:(NSProgress * __autoreleasing *)progress success:(void(^)(id responseObject))success failure:(void(^)(NSError *error))failure {
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager.requestSerializer setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [manager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json",nil];
    
    manager.requestSerializer.timeoutInterval = 5.0f;
    [manager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]!=nil)
    {
        NSString *cookieStr = [NSString stringWithFormat:@"JSESSIONID=%@",[[NSUserDefaults standardUserDefaults] valueForKey:@"SessionID"]];
        [manager.requestSerializer setValue:cookieStr forHTTPHeaderField:@"Cookie"];
    }
    NSMutableURLRequest *request = [[AFJSONRequestSerializer serializer] multipartFormRequestWithMethod:@"PUT" URLString:URLString parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        if (data) {
            [formData appendPartWithFileData:data name:@"file" fileName:@"img" mimeType:@"image/jpeg"];
        }
    } error:nil];
    
    //NSString *urlStringPath = [urlString stringByAppendingPathComponent:rename];
    request.HTTPMethod = @"PUT";
    // 身份验证 BASIC 方式
//    NSString *usernameAndPassword = @"admin:123456";
//    NSData *data = [usernameAndPassword dataUsingEncoding:NSUTF8StringEncoding];
//    NSString *authString = [@"BASIC " stringByAppendingString:[data base64EncodedStringWithOptions:0]];
//    [request setValue:authString forHTTPHeaderField:@"Authorization"];
    void (^completionBlock)(id responseObject, NSError *error) = ^(id responseObject, NSError *error) {
        if (error) {
            if (failure) {
                failure(error);
            }
        } else {
            if (success) {
                success(responseObject);
            }
            
        }
    };
    if (fileURL) {
        [manager uploadTaskWithRequest:request fromFile:fileURL progress:nil completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
            //completionBlock(responseObject, error);
        }];
        return;
    }
//    if (data) {
//        [manager uploadTaskWithRequest:request fromData:bodyData progress:nil completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
//            //completionBlock(responseObject, error);
//        }];
//    }
    return;
}



#pragma mark - UPS应急电源网络接口
+ (void)upsLoginAction:(void(^)(BOOL state, NSString *message))resultBlock
{
    __block BOOL flag = NO;
    NSString *param1 = @"1515352281@qq.com";
    NSString *param2 = @"666666";
    [[HttpTool shareInstance] login:param1 Password:param2 Block:^(NSDictionary * _Nonnull dictionary) {
        //NSLog(@"OKKKKK  登录啦---%@", dictionary[@"status"]);
        NSString *msg = [NSString stringWithFormat:@"%@", dictionary[@"message"]];
        
        // 服务器返回的状态码
        NSString *code = [NSString stringWithFormat:@"%@", dictionary[@"status"]];
        if([code isEqualToString:@"201"] || [code isEqualToString:@"200"] || [msg isEqualToString:@"登录成功"])
        {
            flag = YES;
            if(resultBlock)
            {
                return resultBlock(flag, dictionary[@"message"]);
            }
        }
        else
        {
            if(resultBlock)
            {
                resultBlock(flag, dictionary[@"message"]);
            }
            
        }
    }];
}


+ (void)getUpsMessageListSuccess:(void (^)(id responseObject)) success failure:(void (^)(NSError *error, NSString *message)) failure
{
    NSString *urlString =[NSString stringWithFormat:@"%@/sjtyApi/app/message/getList",Host];
    
    [[HttpTool shareInstance] getRequest:urlString parameters:nil success:^(id responseObject) {
        NSLog(@"获取消息列表---%@", responseObject);
        if (success) {
            success(responseObject);
        }
        
    } failure:^(NSError *error) {
        NSString *message;
        if (error.code==-1001)
        {
            message = TIMEOUT;
        }
        else if (error.code==-1009)
        {
            message = NONETWORK;
        }
        else
        {
            message = ERROR;
        }
        if (failure)
        {
            failure(error, message);
        }
        
    }];
}

+ (void)upsAddNewMessageMode:(NSArray<MessageModel *> *)modelArray success:(void (^)(id responseObject)) success failure:(void (^)(NSError *error, NSDictionary *message)) failure
{
    NSString *urlString =[NSString stringWithFormat:@"http://app.f-union.com/sjtyApi/app/message/addBatch"];
    NSMutableArray *array=[NSMutableArray array];
    for (int i=0; i<modelArray.count; i++) {
        MessageModel *model = modelArray[i];
        //model.productId = PRODUCTID.stringValue;
        NSDictionary *dict= [model toDictionary];
        [array addObject:dict];
    }
    
    [[HttpTool shareInstance] postWithSessionRequest:urlString parameters:array success:^(id responseObject) {
        //
        if (success) {
            success(responseObject);
        }
    } failure:^(NSError *error) {
        //
        NSDictionary *dict;
        if (error.code==-1001) {
            dict=@{@"status":@"-1001",
                   @"message":TIMEOUT
                   };
        }else if (error.code==-1009) {
            dict=@{@"status":@"-1009",
                   @"message":NONETWORK
                   };
        }else{
            dict=@{@"status":@"-1001",
                   @"message":ERROR
                   };
        }
        if (failure)
        {
            failure(error, dict);
        }
    }];
}
// 上传头像的数据信息
+ (void)uploadIconImage:(UIImage *)image success:(void (^)(id response))success failure:(void (^)(NSError * error))failure
{
    NSString *url=[NSString stringWithFormat:@"%@/sjtyApi/app/clientUser/updatePortrait",Host];
    [HttpTool PUT:url data:UIImagePNGRepresentation(image) parameters:nil success:^(id  _Nonnull response) {
        if(success)
        {
            success(response);
        }
    } failure:^(NSError * _Nonnull error) {
        //
    }];
}


// 获得当前服务器中存储的数据信息
+ (void)getUpsRangeDataWithStartDate:(NSDate *)start endDate:(NSDate *)endDate success:(void (^)(id response))success failure:(void (^)(NSError * error))failure
{
    //http://app.shfch.net/sjtyApi/app/upsData/selectByDate
    NSString *urlString=[NSString stringWithFormat:@"%@/sjtyApi/app/upsData/selectByDate",Host];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    if(start && endDate)
    {
        //拼上参数
        [params setObject:[start convertToNumberStringYYYYmmDD] forKey:@"startyyyyMMdd"];
        [params setObject:[endDate convertToNumberStringYYYYmmDD] forKey:@"endyyyyMMdd"];
    }
    else
    {
        //获得当天的数据
        NSDate *now = [NSDate date];
        [params setObject:[now convertToNumberStringYYYYmmDD] forKey:@"yyyyMMdd"];
        
        urlString=[NSString stringWithFormat:@"%@/sjtyApi/app/upsData/selectByDay",Host];
    }
    
    [[HttpTool shareInstance] getRequest:urlString parameters:params success:^(id responseObject) {
        NSLog(@"Range data-------response   %@", responseObject[@"message"]);
        if(success)
        {
            success(responseObject[@"data"]);
        }
    } failure:^(NSError *error) {
#warning 出错的处理
        if(failure)
        {   //
            failure(error);
        }
    }];
}

+ (void)getUpsDateByYYYYstring:(NSString *)yyyy success:(void (^)(NSArray *response))success failure:(void (^)(NSError * error))failure
{
    NSString *urlString=[NSString stringWithFormat:@"%@/sjtyApi/app/upsData/selectByYYYY",Host];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    if([yyyy length] == 4 && [yyyy intValue])
    {
        //拼上参数
        [params setObject:yyyy forKey:@"yyyy"];
    }
    else
    {
        //获得今年d的数据
        NSDate *now = [NSDate date];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"YYYY"];
        [params setObject:[formatter stringFromDate:now] forKey:@"yyyy"];
    }
    
    [[HttpTool shareInstance] getRequest:urlString parameters:params success:^(id responseObject) {
        NSLog(@"Range data-------response   %@", responseObject[@"message"]);
        if(success)
        {
            if([responseObject[@"message"] isEqualToString:@"请求成功"]) success(responseObject[@"data"]);
        }
    } failure:^(NSError *error) {
#warning 出错的处理
        if(failure)
        {   //
            failure(error);
        }
    }];
}


+ (void)postUPSDataToServer:(UpsModel *)model success:(void (^)(NSArray *response))success failure:(void (^)(NSError * error))failure
{
    NSArray* upsPropertys = [model getAllObjCIvarList];
    upsPropertys = [upsPropertys subarrayWithRange:NSMakeRange(0, 24)];
    NSMutableString *param = [NSMutableString string];
    for (NSString *varName in upsPropertys)
    {
        NSString *value = [NSString stringWithFormat:@"%@", [model valueForKey:varName]];
        [param appendString: value];
        [param appendString:@","];
    }
    [param deleteCharactersInRange:NSMakeRange(param.length-1, 1)];
    [param appendString:@";"];
    NSString *urlString=[NSString stringWithFormat:@"%@/sjtyApi/app/upsData/add",Host];

    
    [[HttpTool shareInstance] postWithSessionRequest:urlString parameters:@{@"str": param} success:^(id responseObject) {
        NSLog(@"%@", responseObject);
    } failure:^(NSError *error) {
        // 错误的处理方法
        if(failure)
        {
            failure(error);
        }
    }];
}
@end

@implementation HTTPFormData
+ (HTTPFormData *)instanceWithFileData:(NSData *)data name:(NSString *)name fileName:(NSString *)fileName mineType:(NSString *)mineType
{
    HTTPFormData *formData = [[HTTPFormData alloc] init];
    formData.data = data;
    formData.name = name;
    formData.filename = fileName;
    formData.mimeType = mineType;
    return formData;
}
@end
