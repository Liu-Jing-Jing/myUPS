//
//  SystemTool.m
//  EMS
//
//  Created by 柏霖尹 on 2019/6/28.
//  Copyright © 2019 work. All rights reserved.
//

#import "SystemTool.h"
#import <sys/utsname.h>
@implementation SystemTool

+ (BOOL)IsiPhoneXorNewDevice
{
    if ([[SystemTool iphoneType] isEqualToString:@"iPhone X"] || [[SystemTool iphoneType] isEqualToString:@"iPhone XR"] || [[SystemTool iphoneType] isEqualToString:@"iPhone XS"] || [[SystemTool iphoneType] isEqualToString:@"iPhone XS Max"])
    {
        return YES;
    }
    else
    {
        return NO;
    }
    
}

+ (BOOL)IsiPhonePlusorNewDevice
{
    if ([[SystemTool iphoneType] isEqualToString:@"iPhone 6 Plus"] || [[SystemTool iphoneType] isEqualToString:@"iPhone 7 Plus"] || [[SystemTool iphoneType] isEqualToString:@"iPhone 8 Plus"])
    {
        return YES;
    }
    else
    {
        return NO;
    }
    
}

// 判断手机类型
+ (NSString*)iphoneType
{
        struct utsname systemInfo;
    
        uname(&systemInfo);
    
        NSString*platform = [NSString stringWithCString: systemInfo.machine encoding:NSASCIIStringEncoding];
    
        // simulator 模拟器
    
        if ([platform isEqualToString:@"i386"])   return @"Simulator";
    
        if ([platform isEqualToString:@"x86_64"])   return @"Simulator";
    
       //  常用机型  不需要的可自行删除
    
        if([platform isEqualToString:@"iPhone5,1"])  return @"iPhone 5";
    
        if([platform isEqualToString:@"iPhone5,2"])  return @"iPhone 5";
    
        if([platform isEqualToString:@"iPhone5,3"])  return @"iPhone 5c";
    
        if([platform isEqualToString:@"iPhone5,4"])  return @"iPhone 5c";
    
        if([platform isEqualToString:@"iPhone6,1"])  return @"iPhone 5s";
    
        if([platform isEqualToString:@"iPhone6,2"])  return @"iPhone 5s";
    
        if([platform isEqualToString:@"iPhone7,1"])  return @"iPhone 6 Plus";
    
        if([platform isEqualToString:@"iPhone7,2"])  return @"iPhone 6";
    
        if([platform isEqualToString:@"iPhone8,1"])  return @"iPhone 6s";
    
        if([platform isEqualToString:@"iPhone8,2"])  return @"iPhone 6s Plus";
    
        if([platform isEqualToString:@"iPhone8,4"])  return @"iPhone SE";
    
        if([platform isEqualToString:@"iPhone9,1"])  return @"iPhone 7";
    
        if([platform isEqualToString:@"iPhone9,2"])  return @"iPhone 7 Plus";
    
        if([platform isEqualToString:@"iPhone10,1"]) return @"iPhone 8";
    
        if([platform isEqualToString:@"iPhone10,4"]) return @"iPhone 8";
    
        if([platform isEqualToString:@"iPhone10,2"]) return @"iPhone 8 Plus";
    
        if([platform isEqualToString:@"iPhone10,5"]) return @"iPhone 8 Plus";
    
        if([platform isEqualToString:@"iPhone10,3"]) return @"iPhone X";
    
        if([platform isEqualToString:@"iPhone10,6"]) return @"iPhone X";
    
        if([platform isEqualToString:@"iPhone10,8"]) return @"iPhone XR";
    
        if([platform isEqualToString:@"iPhone10,2"]) return @"iPhone XS";
    
        if([platform isEqualToString:@"iPhone10,4"]) return @"iPhone XS Max";
    
        if([platform isEqualToString:@"iPhone10,6"]) return @"iPhone XS Max";
    
        return platform;
}
@end
