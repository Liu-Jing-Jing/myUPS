//
//  WLCopyLabel.h
//  WLCopyLabel
//
//  Created by wangguoliang on 16/6/23.
//  Copyright © 2016年 wangguoliang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WLCopyLabel : UILabel

@end
