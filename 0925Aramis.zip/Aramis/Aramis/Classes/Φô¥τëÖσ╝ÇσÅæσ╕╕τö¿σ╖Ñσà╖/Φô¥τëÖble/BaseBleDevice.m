//
//  BaseBleDevice.m
//  KangNengWear
//
//  Created by liangss on 2017/10/12.
//  Copyright © 2017年 sjty. All rights reserved.
//

#import "BaseBleDevice.h"
#import "CalendarUtils.h"
#import "NSQueue.h"

@implementation BaseBleDevice


static int weekArr[] = {0,7,1,2,3,4,5,6};


- (instancetype) initWithBabyBluetooth:(BabyBluetooth*)babyBlutooth{
    self = [super init];
    if (self) {
      self->babyBlutooth = babyBlutooth;
#if 0
        //扫描选项->CBCentralManagerScanOptionAllowDuplicatesKey:忽略同一个Peripheral端的多个发现事件被聚合成一个发现事件
      NSDictionary *scanForPeripheralsWithOptions = @{CBCentralManagerScanOptionAllowDuplicatesKey:@YES};
      //连接设备->
      [babyBlutooth setBabyOptionsWithScanForPeripheralsWithOptions:scanForPeripheralsWithOptions connectPeripheralWithOptions:nil scanForPeripheralsWithServices:nil discoverWithServices:nil  discoverWithCharacteristics:nil];
#endif
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveNotifcationValue:) name:BabyNotificationAtDidUpdateValueForCharacteristic object:nil];
        
        self.queue = [[NSQueue alloc] init];
        
       // NSTimer * timer = [NSTimer scheduledTimerWithTimeInterval:0.028 target:self selector:@selector(sendData) userInfo:nil repeats:YES];
       
    }
    return self;
}


-(NSMutableArray*)spiltDataArray {
    if (_spiltDataArray == nil) {
        _spiltDataArray =[NSMutableArray array];
    }
    return _spiltDataArray;
}

-(NSString*)getServiceUUID{
    return @"";
}


-(NSString*)getWriteUUID{
    return @"";
}


-(NSString*)getNotifiUUID{
    return @"";
}

-(NSArray*)deviceName{
    return @[];
}



-(void)setActivityCBPeripheral:(CBPeripheral *)activityCBPeripheral {
    _cbService = nil;
    _writeCharacteristic = nil;
    _notifyCharacteristic = nil;
    _activityCBPeripheral = activityCBPeripheral;
    [self performSelector:@selector(setNotify) withObject:self afterDelay:0.8];
}

-(void)setFilterByName:(BOOL)filter{
    __weak typeof(self) weekSelf = self;
    
    if (filter) {
        [babyBlutooth setFilterOnDiscoverPeripherals:^BOOL(NSString *peripheralName, NSDictionary *advertisementData, NSNumber *RSSI) {
            NSArray* array = [weekSelf deviceName];
            for (NSString *object in array) {//Youngdo_Ble
                if ([object isEqualToString:peripheralName]) {
                    return YES;
                }
            }
            return NO;
        }];
    }
}

-(void)returnValue {
    
    NSMutableString * strData = [NSMutableString string];
    if(self.spiltDataArray.count > 0){
        for (NSString * str in self.spiltDataArray) {
            [strData appendString:str];
        }
    }
    if([self blockFilterNotifyValue]) {
        NSString * filterString = self.blockFilterNotifyValue();
        NSString * headString = [strData substringWithRange:NSMakeRange(0, filterString.length)];
        if ([filterString caseInsensitiveCompare:headString] == NSOrderedSame) {
            
            if ([self blockReturnNotifyValueToView]) {
                [self blockReturnNotifyValueToView](nil,strData);
            }
            //移除所有
        }
    }
    self.iSpiltData = NO;
    [self.spiltDataArray removeAllObjects];
}

-(void)setNotify{
    if (self.activityCBPeripheral) {
        if (self.notifyCharacteristic) {
            __weak typeof(self) weekSelf = self;

            
            [babyBlutooth notify:weekSelf.activityCBPeripheral characteristic:weekSelf.notifyCharacteristic block:^(CBPeripheral *peripheral, CBCharacteristic *characteristics, NSError *error) {
                //NSLog(@"self.activityCBPeripheral==%@ self==%@",weekSelf.activityCBPeripheral,weekSelf);
           
                    
            }];
            
        }
    }
}


- (void)sendCommand:(NSData*)cmd
       notifyBlock:(ReturnNotifyValueToViewBlock) notifyBlock
       filterBlock:(FilterNotifyValueBlock) filterBlock{
    self.blockReturnNotifyValueToView = notifyBlock;
    self.blockFilterNotifyValue = filterBlock;
    
    BabyLog(@"发送的数据为:%@",[BaseUtils stringConvertForData:cmd]);
    
#if 0
    NSString * sendDataStr = [BaseUtils stringConvertForData:cmd];
    NSString * sendStr = [self.logDictionary objectForKey:sendLog];
    
    if (sendStr) {
        
        [self.logDictionary setObject:[NSString stringWithFormat:@"%@\n%@",sendStr,sendDataStr] forKey:sendLog];
    } else {
        [self.logDictionary setObject:sendDataStr forKey:sendLog];
    }
#endif
    
    if (cmd)
    {
        if (self.activityCBPeripheral && self.activityCBPeripheral.state == CBPeripheralStateConnected) {
            [self.activityCBPeripheral writeValue:cmd forCharacteristic:self.writeCharacteristic type:CBCharacteristicWriteWithResponse];
        }
    }
    
//    [self.queue enqueue:cmd];
}


- (void)sendData {
    
    if (![self.queue isEmpty]) {
        NSData* cmd =  [self.queue dequeue];
        BabyLog(@"发送的数据为:%@",[BaseUtils stringConvertForData:cmd]);
#if 0
        NSString * sendDataStr = [BaseUtils stringConvertForData:cmd];

        NSString * sendStr = [self.logDictionary objectForKey:sendLog];
        
        if (sendStr) {
            
            [self.logDictionary setObject:[NSString stringWithFormat:@"%@\n%@",sendStr,sendDataStr] forKey:sendLog];
        } else {
            [self.logDictionary setObject:sendDataStr forKey:sendLog];
        }
#endif
        if (cmd) {
            if (self.activityCBPeripheral && self.activityCBPeripheral.state == CBPeripheralStateConnected) {
                [self.activityCBPeripheral writeValue:cmd forCharacteristic:self.writeCharacteristic type:CBCharacteristicWriteWithResponse];
            }
        }
    }
}

-(CBCharacteristic*)writeCharacteristic{
    if (_writeCharacteristic == nil) {
        for (CBCharacteristic *characteristic in self.cbService.characteristics ) {
           // NSLog(@"characteristic.UUID==%@",characteristic.UUID.UUIDString);
            if ([characteristic.UUID.UUIDString isEqualToString:[[self getWriteUUID] uppercaseString]])
                {
                    _writeCharacteristic = characteristic;
                }
            }
        
        }
    return _writeCharacteristic;
}

-(CBCharacteristic*)notifyCharacteristic{
    if (_notifyCharacteristic == nil) {
        
        
        for (CBCharacteristic *characteristic in self.cbService.characteristics ) {
           // NSLog(@"notifiUUID==%@",characteristic.UUID.UUIDString);

            if ([characteristic.UUID.UUIDString  isEqualToString:[[self getNotifiUUID] uppercaseString]])
            {
                _notifyCharacteristic = characteristic;
            }
        }
    }
    return _notifyCharacteristic;
}

-(CBService*)cbService{
    if (_cbService == nil) {
        for ( CBService *service in self.activityCBPeripheral.services ) {
          //  NSLog(@"serviceUUID==%@",service.UUID.UUIDString);

            if ([service.UUID.UUIDString isEqualToString:[[self getServiceUUID] uppercaseString]]) {
                _cbService = service;
            }
        }
    }
    return _cbService;
}

-(NSString*)getAnsyTimeCmd{
    NSMutableString * string = [NSMutableString string];
    
    NSDate *date = [NSDate date];//这个是NSDate类型的日期，所要获取的年月日都放在这里；
    NSCalendar *cal = [NSCalendar currentCalendar];
    unsigned int unitFlags = NSCalendarUnitYear|NSCalendarUnitMonth|
    NSCalendarUnitDay|NSCalendarUnitWeekday |NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond;//这句是说你要获取日期的元素有哪些。获取年就要写NSYearCalendarUnit，获取小时就要写NSHourCalendarUnit，中间用|隔开；
    NSDateComponents *d = [cal components:unitFlags fromDate:date];//把要从date中获取的unitFlags标示的日期元素存放在NSDateComponents类型的d里面；
    //然后就可以从d中获取具体的年月日了；
    //aa e0 07 e2 08 28 02 18 12 30 ff e4
    //aa e0 07 e2 08 1c 12 10 0c 00 ff 26
    NSInteger year = [d year];
    NSInteger month = [d month];
    NSInteger day  =  [d day];
    NSInteger hour = [d hour];
    NSInteger min = [d minute];
    NSInteger second = [d second];
    NSInteger week = weekArr[[d weekday]];
    NSLog(@"week===%ld",week);
    
    // hexYear + hexMonth + hexDay + hexHour + hexMin + hexSecond;
    
//    [string appendString:[BaseUtils stringConvertForByte:year]];
//    [string appendString:[BaseUtils stringConvertForByte:month]];
//    [string appendString:[BaseUtils stringConvertForByte:day]];
//    [string appendString:[BaseUtils stringConvertForByte:hour]];
//    [string appendString:[BaseUtils stringConvertForByte:min]];
//    [string appendString:[BaseUtils stringConvertForByte:second]];
    
    [string appendString:[BaseUtils stringConvertForShort:year]];
    [string appendString:[BaseUtils stringConvertForByte:month]];
    [string appendString:[BaseUtils stringConvertForByte:day]];
    [string appendString:[BaseUtils stringConvertForByte:hour]];
    [string appendString:[BaseUtils stringConvertForByte:min]];
    [string appendString:[BaseUtils stringConvertForByte:second]];
    
    return string;
}

-(NSMutableDictionary*)logDictionary {
    if (_logDictionary == nil) {
        _logDictionary = [NSMutableDictionary dictionary];
    }
    return _logDictionary;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:BabyNotificationAtDidUpdateValueForCharacteristic object:nil];
}

-(void)receiveNotifcationValue:(NSNotification*)notification {
    NSDictionary*dic = notification.object;
    CBPeripheral* peripheral = dic[@"peripheral"];
    CBCharacteristic* characteristics = dic[@"characteristic"];
  
    if ([peripheral.identifier.UUIDString isEqualToString:self.activityCBPeripheral.identifier.UUIDString] ) {//接收的peripheral 要与当前的activityCBPeripheral 为同一个。
        NSData * data = characteristics.value;
        NSString * strData =  [BaseUtils stringConvertForData:characteristics.value];
        BabyLog(@"接受的数据为:%@",strData);
#if 0
        BabyLog(@"接受的数据为:%@",strData);
        NSString * receiveStr = [self.logDictionary objectForKey:receiveLog];
        
        if (receiveStr) {
            [self.logDictionary setObject:[NSString stringWithFormat:@"%@\n%@",receiveStr,strData] forKey:receiveLog];
        } else {
            [self.logDictionary setObject:strData forKey:receiveLog];
        }
#endif
        if ([self iSpiltData]) {
            [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(returnValue) object:nil];
            [self.spiltDataArray addObject:strData];
            [self performSelector:@selector(returnValue) withObject:nil afterDelay:0.5];
            
        } else {
            
            if([self blockFilterNotifyValue]) {
                
                NSString * filterString = self.blockFilterNotifyValue();
                NSString * headString = [strData substringWithRange:NSMakeRange(0, filterString.length)];
                if ([filterString caseInsensitiveCompare:headString] == NSOrderedSame) {
                    if ([self blockReturnNotifyValueToView]) {
                        [self blockReturnNotifyValueToView](data,strData);
                    }
                }
            }
        }
        [self receiveData:data];
    }
}

- (void)receiveData:(NSData*)data {
    
    
}

/**
 *清除数据缓存
 */
- (void)cleanDataBuffer {
    if (self.queue) {
        [self.queue clearQueue];
    }
}

-(void)cleanObject {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:BabyNotificationAtDidUpdateValueForCharacteristic object:nil];
    if (self.queue) {
        [self.queue clearQueue];
    }
}


@end
