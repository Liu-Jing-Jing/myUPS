//
//  SPActivityIndicator3DotsExchangePositionAnimation.h
//  SPActivityIndicatorExample
//
//  Created by Libo on 2017/12/29.
//  Copyright © 2017年 iDress. All rights reserved.
//

#import "SPActivityIndicatorAnimation.h"

@interface SPActivityIndicator3DotsExchangePositionAnimation : SPActivityIndicatorAnimation

@end
