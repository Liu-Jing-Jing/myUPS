//
//  SPActivityIndicatorBallPulseAnimation.h
//  SPActivityIndicatorExample
//
//  Created by Nguyen Vinh on 7/19/15.
//  Copyright (c) 2015 iDress. All rights reserved.
//

#import "SPActivityIndicatorAnimation.h"

@interface SPActivityIndicatorBallPulseAnimation: SPActivityIndicatorAnimation

@end
