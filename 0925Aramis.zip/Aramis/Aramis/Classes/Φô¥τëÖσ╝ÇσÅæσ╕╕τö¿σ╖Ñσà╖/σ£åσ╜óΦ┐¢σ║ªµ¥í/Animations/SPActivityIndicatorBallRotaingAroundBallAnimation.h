//
//  SPActivityIndicatorBallRotaingAroundBallAnimation.h
//  SPActivityIndicatorExample
//
//  Created by Libo on 2017/12/29.
//  Copyright © 2017年 iDress. All rights reserved.
//

#import "SPActivityIndicatorAnimation.h"

@interface SPActivityIndicatorBallRotaingAroundBallAnimation : SPActivityIndicatorAnimation

@end
