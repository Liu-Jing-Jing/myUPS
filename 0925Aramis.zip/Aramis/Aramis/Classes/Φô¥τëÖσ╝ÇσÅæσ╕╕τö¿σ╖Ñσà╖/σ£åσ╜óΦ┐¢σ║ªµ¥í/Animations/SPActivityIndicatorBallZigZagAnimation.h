//
//  SPActivityIndicatorBallZigZagAnimation.h
//  SPActivityIndicatorExample
//
//  Created by Nguyen Vinh on 7/20/15.
//  Copyright (c) 2015 iDress. All rights reserved.
//

#import "SPActivityIndicatorAnimation.h"

@interface SPActivityIndicatorBallZigZagAnimation: SPActivityIndicatorAnimation

@end
