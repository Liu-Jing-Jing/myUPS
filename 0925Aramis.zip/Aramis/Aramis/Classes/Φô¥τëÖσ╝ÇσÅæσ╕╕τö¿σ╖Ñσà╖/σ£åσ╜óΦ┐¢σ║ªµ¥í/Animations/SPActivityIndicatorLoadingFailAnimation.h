//
//  SPActivityIndicatorLoadingFailAnimation.h
//  SPActivityIndicatorExample
//
//  Created by Libo on 2017/12/28.
//  Copyright © 2017年 iDress. All rights reserved.
//

#import "SPActivityIndicatorAnimation.h"

@interface SPActivityIndicatorLoadingFailAnimation : SPActivityIndicatorAnimation

@end
