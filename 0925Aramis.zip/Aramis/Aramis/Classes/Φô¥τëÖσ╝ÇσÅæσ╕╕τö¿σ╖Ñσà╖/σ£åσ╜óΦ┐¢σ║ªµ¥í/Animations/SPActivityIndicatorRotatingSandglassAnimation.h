//
//  SPActivityIndicatorRotatingTrigonsAnimation.h
//  SPActivityIndicatorExample
//
//  Created by 乐升平 on 15/6/26.
//  Copyright (c) 2015年 iDress. All rights reserved.
//

#import "SPActivityIndicatorAnimation.h"

@interface SPActivityIndicatorRotatingSandglassAnimation: SPActivityIndicatorAnimation


@end
