

//
//  UnsyncUPSModel.m
//  Natures
//
//  Created by 柏霖尹 on 2019/9/15.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import "UnsyncUPSModel.h"

@implementation UnsyncUPSModel

@end
