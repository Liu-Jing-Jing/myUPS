//
//  DeviceViewCell.m
//  Natures
//
//  Created by 柏霖尹 on 2019/7/24.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import "DeviceViewCell.h"
@interface DeviceViewCell()
@end
@implementation DeviceViewCell
customCell_implementation(DeviceViewCell);
@end
