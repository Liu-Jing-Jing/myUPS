//
//  MessageController.h
//  Natures
//
//  Created by sjty on 2019/7/10.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MessageModel.h"
#import "BaseViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface MessageController : BaseViewController<UITableViewDelegate, UITableViewDataSource>

@end

NS_ASSUME_NONNULL_END
