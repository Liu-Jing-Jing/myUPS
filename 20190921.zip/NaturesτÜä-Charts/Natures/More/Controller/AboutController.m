//
//  AboutController.m
//  Natures
//
//  Created by sjty on 2019/7/19.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import "AboutController.h"

@interface AboutController ()

@end

@implementation AboutController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}



@end
