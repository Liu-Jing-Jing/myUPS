//
//  FeedBackController.m
//  Natures
//
//  Created by sjty on 2019/7/19.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import "FeedBackController.h"

@interface FeedBackController ()

@end

@implementation FeedBackController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}



@end
