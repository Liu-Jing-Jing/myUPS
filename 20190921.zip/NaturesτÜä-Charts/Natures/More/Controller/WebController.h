//
//  WebController.h
//  Natures
//
//  Created by sjty on 2019/7/19.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WebController : UIViewController

@end

NS_ASSUME_NONNULL_END
