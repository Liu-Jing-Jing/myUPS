//
//  DetailWebViewController.h
//  Natures
//
//  Created by 柏霖尹 on 2019/8/5.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Masonry.h"
#import "BaseViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface DetailWebViewController : BaseViewController
@property (nonatomic, strong) NSURL *url;
@end

NS_ASSUME_NONNULL_END
