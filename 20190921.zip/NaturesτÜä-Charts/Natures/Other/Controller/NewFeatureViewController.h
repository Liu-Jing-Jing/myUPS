//
//  NewFeatureViewController.h
//  Natures
//
//  Created by 柏霖尹 on 2019/8/9.
//  Copyright © 2019 com.sjty. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@interface NewFeatureViewController : UIViewController
@property (nonatomic,weak) UIPageControl *pageControl;
@end

NS_ASSUME_NONNULL_END
