//
//  SymbolsValueFormatter.h
//  ChartsTest
//
//  Created by 柏霖尹 on 2019/7/24.
//  Copyright © 2019 work. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Natures-Bridging-Header.h"
NS_ASSUME_NONNULL_BEGIN


@interface SymbolsValueFormatter : NSObject<IChartAxisValueFormatter>

@end
NS_ASSUME_NONNULL_END
